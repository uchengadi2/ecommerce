<?php

class PricingController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update','listAllPricingOfThisProductInAWarehouse','addpriceperunittoproductinawarehouse','removepriceperunitofproductinawarehouse',
                                    'updatepriceperunitofproductinawarehouse','listAllPricingOfThisProductInAllWarehouses','makethispricethedefaultforthisproduct','removethispriceasthedefaultforthisproduct',
                                    'updatethedefaultforthisproduct','listAllPricing','listallproductpricinginawarehouse','retrievethemeasurementsymbolofthispricing','retrievedetailsofthispricing'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	/**
	 * Displays a particular model.
	 * @param integer $id the ID of the model to be displayed
	 */
	public function actionView($id)
	{
		$this->render('view',array(
			'model'=>$this->loadModel($id),
		));
	}

	
        /**
         * This is the function that list all pricing of a product in a warehouse
         */
        public function actionlistAllPricingOfThisProductInAWarehouse(){
            $model = new Inventory;
            
            $product_id = $_REQUEST['product_id'];
            $warehouse_id = $_REQUEST['warehouse_id'];
            
            //get the required inventory id
            $inventory_id = $model->getTheInventoryIdOfThisInventory($product_id, $warehouse_id);
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='inventory_id=:invid';
            $criteria->params = array(':invid'=>$inventory_id);
            $pricing = Pricing::model()->findAll($criteria);
            
             header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "pricing" => $pricing
                                       
                                       )
                           );
                       
        }
        
        
        /**
         * This is the function that adds pricing per unit to a product in a warehouse
         */
        public function actionaddpriceperunittoproductinawarehouse(){
            $model = new Pricing;
            
            $product_id = $_REQUEST['product_id'];
            $warehouse_id = $_REQUEST['warehouse_id'];
            $warehouse_name = $_REQUEST['warehouse_name'];
             //get the required inventory id
            $inventory_id = $this->getTheInventoryIdOfThisInventory($product_id, $warehouse_id);
            
            $model->inventory_id = $inventory_id;
            $model->price_per_unit= $_REQUEST['price_per_unit'];
            $model->measurement_type_id = $_REQUEST['measurement_type_id'];
            $model->prime_customer_discount_rate = $_REQUEST['prime_customer_discount_rate'];
            $model->minimum_order_quantity = $_REQUEST['minimum_order_quantity'];
            
            if($model->isThisPriceAlreadyAssignedToThisProduct($model->measurement_type_id,$inventory_id)==false){
                if($model->save()){
                    //register this pricing for promotion
                    $this->registerPricingForPromotion($model->id);
                $msg = "This price per unit is successfully assigned to this product in the '$warehouse_name' warehouse ";
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg)
                           );
            }else{
                $msg = "Attempt to assign this price per unit to the product in  this '$warehouse_name' warehouse was unsuccessful";
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg)
                           );
            }
                
                
            }else{
                $msg = "This unit measurement type already had an assigned price per unit on this product in this '$warehouse_name' warehouse. Therefore the request is ignored";
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg)
                           );
                
            }
            
        }
        
        
        
       /**
        * Thsi is the function that registers a new pricing for promotion
        */
        public function registerPricingForPromotion($id){
            $model = new Promotion;
            return $model->registerPricingForPromotion($id);
        }
        
        
        /**
         * This is the function that adds pricing per unit to a product in a warehouse
         */
        public function actionupdatepriceperunitofproductinawarehouse(){
                       
            $product_id = $_REQUEST['product_id'];
            $warehouse_id = $_REQUEST['warehouse_id'];
            $warehouse_name = $_REQUEST['warehouse_name'];
            $measurement_type_id = $_REQUEST['measurement_type_id'];
            
             //get the required inventory id
            $inventory_id = $this->getTheInventoryIdOfThisInventory($product_id, $warehouse_id);
            
            if($this->isThisPriceAlreadyAssignedToThisProduct($measurement_type_id,$inventory_id)){
                //get the required pricing id
            $pricing_id = $this->getThePricingIdOfThisProductInTheWarehouse($product_id, $warehouse_id,$measurement_type_id);
            
            $model= Pricing::model()->findByPk($pricing_id);
            
            $model->inventory_id = $inventory_id;
            $model->price_per_unit= $_REQUEST['price_per_unit'];
            $model->measurement_type_id = $measurement_type_id;
            $model->prime_customer_discount_rate = $_REQUEST['prime_customer_discount_rate'];
            $model->minimum_order_quantity = $_REQUEST['minimum_order_quantity'];
            
            if($model->save()){
                $msg = "This price per unit is successfully updated on this product in the '$warehouse_name' warehouse ";
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg)
                           );
            }else{
                $msg = "Attempt to update this price per unit on the product in  this '$warehouse_name' warehouse was unsuccessful";
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg)
                           );
            }
                
                
           
                
            }else{
                $msg = "This unit measurement type do not currently have an assigned price per unit on this product in the '$warehouse_name' warehouse and therefore the request is ignored";
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg)
                           );
                
            }
            
            
        }
        
        
        
        
        /**
         * This is the function that removes a price per unit from a product in a warehous
         */
        public function actionremovepriceperunitofproductinawarehouse(){
            
                    
            $product_id = $_REQUEST['product_id'];
            $warehouse_id = $_REQUEST['warehouse_id'];
            $warehouse_name = $_REQUEST['warehouse_name'];
            $measurement_type_id = $_REQUEST['measurement_type_id'];
            
             //get the required inventory id
            $inventory_id = $this->getTheInventoryIdOfThisInventory($product_id, $warehouse_id);
            
          if($this->isThisPriceAlreadyAssignedToThisProduct($measurement_type_id,$inventory_id)){
             //get the required pricing id
            $pricing_id = $this->getThePricingIdOfThisProductInTheWarehouse($product_id, $warehouse_id,$measurement_type_id);
            
            $model= Pricing::model()->findByPk($pricing_id);
            
          
                if($model->isTheRemovalOfThisPricePerUnitFromThisProductInTheWarehouseASuccess($model)){
                    $msg = "The price per unit is successfully removed from this product in the  '$warehouse_name' warehouse";
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg)
                           );
                }else{
                    $msg = "Attempt to remove this price per unit from this product in the '$warehouse_name' warehouse was unsuccessful";
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg)
                           );
                }
           }else{
                $msg = "This unit measurement type do not currently have an assigned price per unit on this product in the '$warehouse_name' warehouse and therefore the request is ignored";
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg)
                           );
           }
            
            
        }
        
        
        
        /**
         * This is the function that gets an inventory id
         */
        public function getTheInventoryIdOfThisInventory($product_id, $warehouse_id){
            $model = new Inventory;
            return $model->getTheInventoryIdOfThisInventory($product_id, $warehouse_id);
        }
        
        /**
         * This is the function that retrieves the pricing id of a product in a warehouse
         */
        public function getThePricingIdOfThisProductInTheWarehouse($product_id, $warehouse_id,$measurement_type_id){
            $model = new Pricing;
            return $model->getThePricingIdOfThisProductInTheWarehouse($product_id, $warehouse_id,$measurement_type_id);
        }
        
        
        /**
         * This is the function that confims if the pricing of a measurement type is already assigned
         */
        public function isThisPriceAlreadyAssignedToThisProduct($measurement_type_id,$inventory_id){
            $model = new Pricing;
            return $model->isThisPriceAlreadyAssignedToThisProduct($measurement_type_id,$inventory_id);
        }
        
        
        
        
        /**
         * This is the function that list all pricing of a product in all warehouse
         */
        public function actionlistAllPricingOfThisProductInAllWarehouses(){
            $model = new Inventory;
            
            $product_id = $_REQUEST['product_id'];
                      
            //get the required inventory ids associated with this product id
            $inventories = $model->getAllTheInventoryIdsAssociatedWithProducts($product_id);
            
            $target = [];
            
            foreach($inventories as $inv){
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='inventory_id=:invid';
                $criteria->params = array(':invid'=>$inv);
                $pricings = Pricing::model()->findAll($criteria);
                
                foreach($pricings as $price){
                    $target[] = $price;
                }
                
            }
            
            
            
            if($inventories===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "pricing" => $target,
                                         "inventories"=>$inventories
                                       
                                       )
                           );
                       
                }
        }
        
        
        /**
         * This is the function that makes price the default price of a product
         */
        public function actionmakethispricethedefaultforthisproduct(){
            
            $model = new Pricing;
            
            $product_id = $_REQUEST['product_id'];
            $warehouse_id = $_REQUEST['warehouse_id'];
            //get the required inventory id
            $inventory_id = $this->getTheInventoryIdOfThisInventory($product_id, $warehouse_id);
            
            if($inventory_id != null){
                $model->inventory_id = $inventory_id;
                $model->price_per_unit= $_REQUEST['price_per_unit'];
                 $model->is_default_price= 1;
                $model->measurement_type_id = $_REQUEST['measurement_type_id'];
                $model->prime_customer_discount_rate = $_REQUEST['prime_customer_discount_rate'];
                $model->minimum_order_quantity = $_REQUEST['minimum_order_quantity'];
            
            if($model->isThisPriceAlreadyAssignedToThisProduct($model->measurement_type_id,$inventory_id)==false){
                if($model->isThisProductAlreadyWithDefaultPrice($product_id) == false){
                         if($model->save()){
                             //register dummy promotion
                           $this->registerPricingForPromotion($model->id);  
                $msg = "This default price is successfully set for this product";
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg)
                           );
            }else{
                $msg = "Attempt to assign this default price per unit to this product in  this warehouse was unsuccessful";
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg)
                           );
            }
                    
                }else{
                     $msg = "This product already have a default price possibly in another warehouse. You have to remove that default price before adding another one.";
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg)
                           );
                    
                }
               
                
                
            }else{
                $msg = "This unit measurement type already had an assigned price per unit on this product in the warehouse. If you want to use this measurement type for this product default pricing, it is best to first remove it and try adding the default price again";
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg)
                           );
                
            }
            
                
            }else{
                $msg = "This warehouse is either without inventory or the inventory do not include this product. Kindly select another warehouse and try again or add the product to the warehouse and try again";
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg)
                           );
                
                
                
            }
            
            
            
        }
        
        
        
        
        /**
         * This is the function that update he default price of a product
         */
        public function actionupdatethedefaultforthisproduct(){
            
                        
            $product_id = $_REQUEST['product_id'];
            $warehouse_id = $_REQUEST['warehouse_id'];
            $measurement_type_id = $_REQUEST['measurement_type_id'];
            //get the required inventory id
            $inventory_id = $this->getTheInventoryIdOfThisInventory($product_id, $warehouse_id);
            
            if($inventory_id != null){
                            
            if($this->isThisPriceAlreadyAssignedToThisProduct($measurement_type_id,$inventory_id)){
                
                 $pricing_id = $this->getTheDefaultPricingIdOfThisProductInTheWarehouse($product_id, $warehouse_id);
            
                $model= Pricing::model()->findByPk($pricing_id);
                $model->inventory_id = $inventory_id;
                $model->price_per_unit= $_REQUEST['price_per_unit'];
                $model->is_default_price= 1;
                $model->measurement_type_id = $_REQUEST['measurement_type_id'];
                $model->prime_customer_discount_rate = $_REQUEST['prime_customer_discount_rate'];
                $model->minimum_order_quantity = $_REQUEST['minimum_order_quantity'];
                if($model->isThisProductAlreadyWithDefaultPrice($product_id)){
                 if($model->save()){
                    $msg = "This default price for this product is updated successfully";
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg)
                           );
            }else{
                $msg = "Attempt to update the default price of this product was unsuccessful";
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg)
                           );
            }
                    
                }else{
                     $msg = "This product do not have any default price assigned to it, therefore the request is ignored.";
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg)
                           );
                    
                }
               
                
                
            }else{
                $msg = "It appears you are trying to use a unit measurement type that is already in use in this warehouse. Please check the measurement type and try again";
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg)
                           );
                
            }
            
                
            }else{
                $msg = "This warehouse is either without inventory or the inventory do not include this product. Kindly select another warehouse and try again or add the product to the warehouse and try again";
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg)
                           );
                
                
                
            }
            
            
            
        }
        
        
        /**
         * this is the function that gets the default pricing id of an inventory
         */
    public function getTheDefaultPricingIdOfThisProductInTheWarehouse($product_id, $warehouse_id){
               $model = new Pricing;
                return $model->getTheDefaultPricingIdOfThisProductInTheWarehouse($product_id, $warehouse_id);
    }
    
    
    
     /**
         * This is the function that removes the default price of a product
         */
        public function actionremovethispriceasthedefaultforthisproduct(){
            
                        
            $product_id = $_REQUEST['product_id'];
            $warehouse_id = $_REQUEST['warehouse_id'];
            //$measurement_type_id = $_REQUEST['measurement_type_id'];
            //get the required inventory id
            $inventory_id = $this->getTheInventoryIdOfThisInventory($product_id, $warehouse_id);
            
            if($inventory_id != null){
                            
           if($this->isThisProductAlreadyWithDefaultPrice($product_id)){
                
                 $pricing_id = $this->getTheDefaultPricingIdOfThisProductInTheWarehouse($product_id, $warehouse_id);
                 $model= Pricing::model()->findByPk($pricing_id);
            
                if($model->isTheRemovalOfThisPricePerUnitFromThisProductInTheWarehouseASuccess($model)){
                    $msg = "The default price per unit is successfully removed from this product";
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg)
                           );
                }else{
                    $msg = "Attempt to remove this default price per unit from this product was unsuccessful";
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg)
                           );
                }
                    
                }else{
                     $msg = "This product do not have any default price assigned to it, therefore the request is ignored.";
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg)
                           );
                    
                }
               
                
                
           
            
                
            }else{
                $msg = "This warehouse is either without inventory or the inventory do not include this product. Kindly select another warehouse and try again or add the product to the warehouse and try again";
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg)
                           );
                
                
                
            }
            
            
            
        }
        
        
        /**
         * This isthe function that confirms if a product has a default price
         */
        public function isThisProductAlreadyWithDefaultPrice($product_id){
            $model = new Pricing;
            return $model->isThisProductAlreadyWithDefaultPrice($product_id);
        }
        
        /**
         * This is the function that list all pricing
         */
        public function actionlistAllPricing(){
            $pricing = Pricing::model()->findAll();
               header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "pricing" => $pricing,
                                   
                    
                            ));
        }
        
        
        
        /**
         * This is the function that list all pricing of a product in a warehouse
         */
        public function actionlistallproductpricinginawarehouse(){
            $model = new Inventory;
            
            $warehouse_id = $_REQUEST['warehouse_id'];
            $product_id = $_REQUEST['product_id'];
            
            //get the inventory id of this product
            $inventory_id =$model->getTheInventoryIdOfThisInventory($product_id, $warehouse_id);
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='inventory_id=:invid';
            $criteria->params = array(':invid'=>$inventory_id);
            $pricing= Pricing::model()->findAll($criteria);
            
             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "pricing" => $pricing,
                                   
                    
                            ));
        }
        
        
        /**
         * This is the function that retrieves the symbol of a pricing measurement type
         */
        public function actionretrievethemeasurementsymbolofthispricing(){
            $model = new MeasurementType;
            $pricing_id = $_REQUEST['pricing_id'];
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$pricing_id);
            $pricing= Pricing::model()->find($criteria);
            
            $symbol = $model->getTheSymbolOfThisMeasurementType($pricing['measurement_type_id']);
            
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "symbol" => $symbol,
                                   
                    
                            ));
            
        }
        
        
        /**
         * This is the the function that retrieves the details of a pricing
         */
        public function actionretrievedetailsofthispricing(){
            
            $model = new MeasurementType;
            $pricing_id = $_REQUEST['pricing_id'];
            
            //get the details of this pricing
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$pricing_id);
            $pricing= Pricing::model()->find($criteria);
            
            $product = $this->getTheProductWithThisPricing($pricing['inventory_id']);
            $warehouse = $this->getTheWarehouseForThisPricing($pricing['inventory_id']);
            $symbol = $model->getTheSymbolOfThisMeasurementType($pricing['measurement_type_id']);
            $price = $pricing['price_per_unit'];
            
             header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "symbol" => $symbol,
                                    "product"=>$product,
                                    "warehouse"=>$warehouse,
                                    "price"=>$price,
                                    "pricing"=>$pricing
                                   
                    
                            ));
        }
        
        
        /**
         * This is the function retrieves a product for a pricing
         */
        public function getTheProductWithThisPricing($inventory_id){
            $model = new Inventory;
            return $model->getTheProductWithThisPricing($inventory_id);
        }
        
        
         /**
         * This is the function retrieves a product warehouse for a pricing
         */
        public function getTheWarehouseForThisPricing($inventory_id){
            $model = new Inventory;
            return $model->getTheWarehouseForThisPricing($inventory_id);
        }
        
}
