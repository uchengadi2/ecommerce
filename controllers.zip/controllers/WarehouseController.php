<?php

class WarehouseController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update','modifywarehouse','addnewwarehouse','deleteonewarehouse','listallmerchantwarehouses',
                                    'listAllWarehouses','listTheWarehousesWhereThisProductIsStored'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	/**
         * Thsi is the function that adds a new merchants warehouse
         */
        public function actionaddnewwarehouse(){
            
            $model = new Warehouse;
            $user_id = Yii::app()->user->id;
            
            $merchant_id = $model->getTheMerchantIdOfThisUser($user_id);
            
            $model->name = $_POST['name'];
            $model->city_id = $_POST['city_id'];
            if(isset($_POST['address'])){
                $model->address = $_POST['address'];
            }
            if(isset($_POST['description'])){
                $model->description = $_POST['description'];
            }
            $model->merchant_id = $merchant_id;
            
            $model->create_time = new CDbExpression('NOW()');
            $model->create_user_id = Yii::app()->user->id;
            if($model->save()){
                         // $result['success'] = 'true';
                          $msg = "'$model->name' warehouse is successfully added";
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                        "msg" => $msg)
                           );
                     }else {
                         //$result['success'] = 'false';
                         $msg = "Attempt to add '$model->name' warehouse failed";
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                           );
                    } 
            
        }
        
        
        
        /**
         * Thsi is the function that modifies merchants warehouse
         */
        public function actionmodifywarehouse(){
            
             $_id = $_POST['id'];
            
            $model=Warehouse::model()->findByPk($_id);
            
            $model->name = $_POST['name'];
            $model->city_id = $_POST['city_id'];
            $model->merchant_id = $_POST['merchant_id'];
            if(isset($_POST['address'])){
                $model->address = $_POST['address'];
            }
            if(isset($_POST['description'])){
                $model->description = $_POST['description'];
            }
            $model->merchant_id = $_POST['merchant_id'];
            
            $model->create_time = new CDbExpression('NOW()');
            $model->create_user_id = Yii::app()->user->id;
            if($model->save()){
                         // $result['success'] = 'true';
                          $msg = "'$model->name' warehouse is successfully updated";
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                        "msg" => $msg)
                           );
                     }else {
                         //$result['success'] = 'false';
                         $msg = "Attempt to update '$model->name' warehouse failed";
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                           );
                    } 
            
        }
        
        
         /**
	 * Deletes a particular model instance
	 * 
         **/
	public function actiondeleteonewarehouse()
	{
            
            $_id = $_REQUEST['id'];
            $model=  Warehouse::model()->findByPk($_id);
            
            //get the state name
            $name = $_POST['name'];
            
            
            if($model === null){
                $data['success'] = 'undefined';
                $data['msg'] = 'No such record exist';
                header('Content-Type: application/json');
                echo CJSON::encode($data);
                                      
            }else if($model->delete()){
                    $data['success'] = 'true';
                    $data['msg'] = "'$name' warehouse was successfully deleted";
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
            } else {
                    $data['success'] = 'false';
                    $data['msg'] = 'deletion unsuccessful';
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
                            
                }
	}
        
        
        
       /**
         * This is the function that list all merchant warehouses
         */
        public function actionlistallmerchantwarehouses(){
           $model = new User;
            $user_id = Yii::app()->user->id;
            
            $merchant_id = $model->getTheMerchantIdOfThisUser($user_id);
            
              $criteria = new CDbCriteria();
              $criteria->select = '*';
              $criteria->condition='merchant_id=:merid';
              $criteria->params = array(':merid'=>$merchant_id);
              $warehouse= Warehouse::model()->findAll($criteria);
              if($warehouse===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                         header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "warehouse" => $warehouse,
                                   
                    
                            ));
                       
                       
                }
            
        }
        
        
        /**
         * This is the function that list all warehouses
         */
        public function actionlistAllWarehouses(){
            
             $model = new Warehouse;
            
             $warehouses = Warehouse::model()->findAll();
                if($warehouses===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                        header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "warehouse" => $warehouses,
                                   
                    
                            ));
                       
                }
        }
        
        
        /**
         * This is the function that list all warehouses where a product is stored
         */
        public function actionlistTheWarehousesWhereThisProductIsStored(){
            
            $model = new Inventory;
            
            $product_id = $_REQUEST['product_id'];
            
            $target = [];
            
            //get all warehouse that is storing this product
            $warehouses = $model->getAllWarehouseThatIsStoringThisProduct($product_id);
            
            foreach($warehouses as $warehouse){
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$warehouse);
                $ware= Warehouse::model()->find($criteria);
                
                $target[] = $ware;
            }
            
            if($warehouses===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                        header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "warehouse" => $target,
                                   
                    
                            ));
                       
                }
        }
        
        
       
}
