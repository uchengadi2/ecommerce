<?php

class MeasurementTypeController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view','listcustomerbasedmeasurementtypesforthiscategory','listcustomerbasedmeasurementtypesforthiscategoryforngadi',
                                    'listAllMeasurementTypes','listcustomerbasedmeasurementtypesforthisproducttype'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update','listAllMeasurementTypes','modifymeasurementtype','addnewmeasurementtype','deleteonemeasurementtype',
                                    'removemeasurementtypetocategory','addmeasurementtypetocategory','listAllCategoryMeasurementTypes','listAllClassificationMeasurementTypes',
                                    'listCategoryMeasurementTypes','listThisProductPreferredMeasurementType','listcustomerbasedmeasurementtypesforthiscategory'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	/**
         * This is the function that list all measurement types
         */
        public function actionlistAllMeasurementTypes(){
            
             $model = new MeasurementType;
            
             $types = MeasurementType::model()->findAll();
                if($types===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                        header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "type" => $types,
                                   
                    
                            ));
                       
                }
        }
        
        
        
        /**
         * This is the function that add new measurement type
         */
        public function actionaddnewmeasurementtype(){
            $model=new MeasurementType;

		
                $model->name = $_POST['name'];
                $model->symbol = $_POST['symbol'];
                $model->weight_equivalence_in_kg = $_POST['weight_equivalence_in_kg'];
                if(isset($_POST['description'])){
                   $model->description = $_POST['description']; 
                }
                                 
                $model->create_time = new CDbExpression('NOW()');
                $model->create_user_id = Yii::app()->user->id;
                
                $icon_error_counter = 0;
                
                 if($_FILES['icon']['name'] != ""){
                    if($model->isIconTypeAndSizeLegal()){
                        
                       $icon_filename = $_FILES['icon']['name'];
                     
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $icon_filename = NULL;   
                   //$icon_size = 0;
             
                }//end of the if icon is empty statement
                if($icon_error_counter ==0){
                   if($model->validate()){
                           $model->icon = $model->moveTheIconToItsPathAndReturnTheIconName($model,$icon_filename);
                           
                           
                       if($model->save()) {
                        
                                $msg = "'$model->name' measurement type was created successful";
                                 header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                 "success" => mysqli_connect_errno() == 0,
                                  "msg" => $msg)
                            );
                         
                        }else{
                            //delete all the moved files in the directory when validation error is encountered
                            $msg = 'Validaion Error: Check your file fields for correctness';
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                               );
                          }
                            }else{
                                
                                //delete all the moved files in the directory when validation error is encountered
                            $msg = "Validation Error: '$model->name' measurement type was not created successful";
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                            );
                          }
                   }elseif($icon_error_counter > 0){
                        $msg = "Please check the image you uploaded and ensure that they meet the requirements. Note that the images must have a minimum size of 1000px by 1000px and they must either be in  .png or .jpg file format";
                            header('Content-Type: application/json');
                                    echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                    "msg" => $msg)
                            );
                         
                        } 
            
        }
        
        
        
        /**
         * This is the function that updates the measurement type information
         */
        public function actionmodifymeasurementtype(){
            
             $_id = $_POST['id'];
             $model=  MeasurementType::model()->findByPk($_id);
             
             $model->name = $_POST['name'];
                $model->symbol = $_POST['symbol'];
                $model->weight_equivalence_in_kg = $_POST['weight_equivalence_in_kg'];
                if(isset($_POST['description'])){
                   $model->description = $_POST['description']; 
                }
                                 
                $model->update_time = new CDbExpression('NOW()');
                $model->update_user_id = Yii::app()->user->id;
                
                $icon_error_counter = 0;
                
                 if($_FILES['icon']['name'] != ""){
                    if($model->isIconTypeAndSizeLegal()){
                        
                       $icon_filename = $_FILES['icon']['name'];
                      //$icon_size = $_FILES['flag']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $icon_filename = $model->retrieveThePreviousIconName($_id);
                   //$icon_size = 0;
             
                }//end of the if icon is empty statement
                if($icon_error_counter ==0){
                   if($model->validate()){
                           $model->icon = $model->moveTheIconToItsPathAndReturnTheIconName($model,$icon_filename);
                          
                           
                       if($model->save()) {
                        
                                $msg = "'$model->name' measurement type was updated successful";
                                 header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                 "success" => mysqli_connect_errno() == 0,
                                  "msg" => $msg)
                            );
                         
                        }else{
                            //delete all the moved files in the directory when validation error is encountered
                            $msg = 'Validaion Error: Check your file fields for correctness';
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                               );
                          }
                            }else{
                                
                                //delete all the moved files in the directory when validation error is encountered
                            $msg = "Validation Error: '$model->name'  measurement type was not updated successful";
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                            );
                          }
                   }elseif($icon_error_counter > 0){
                        $msg = "Please check the image you uploaded and ensure that they meet the requirements. Note that the images must have a minimum size of 1000px by 1000px and they must either be in  .png or .jpg file format";
                            header('Content-Type: application/json');
                                    echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                    "msg" => $msg)
                            );
                         
                        } 
     
        }
        
        
        
        /**
         * This is the function that deletes a measurement type from the database
         */
        public function actiondeleteonemeasurementtype(){
            
            $_id = $_POST['id'];
            $model=  MeasurementType::model()->findByPk($_id);
            $type_name = $_POST['name'];
            
            if($model->isTheRemovalOfMeasurementTypeImageASuccess($_id)){
            
            if($model === null){
                $data['success'] = 'undefined';
                $data['msg'] = 'No such record exist';
                header('Content-Type: application/json');
                echo CJSON::encode($data);
                                      
            }else if($model->delete()){
                    $data['success'] = 'true';
                    $data['msg'] = "'$type_name' was successfully deleted";
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
            } else {
                    $data['success'] = 'false';
                    $data['msg'] = 'deletion was unsuccessful';
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
                            
                }
                
            }else{
                $data['success'] = 'false';
                    $data['msg'] = 'deletion was unsuccessful';
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
            }
            
            
            
        }
        
        
        
        /**
         * This is the function that list all measurement types assigned to a category
         */
        public function actionlistAllCategoryMeasurementTypes(){
            
            $model = new CategoryMeasurementType;
            $category_id = $_REQUEST['category_id'];
            $measurement_type_id = $_REQUEST['measurement_type_id'];
                    
            $types = $model->retrieveAllMeasurementTypesAlreadyAssignedToACategory($category_id);
            
            $target = [];
            
            if($types != null){
                foreach($types as $type){
              $criteria = new CDbCriteria();
              $criteria->select = '*';
              $criteria->condition='id=:id';
              $criteria->params = array(':id'=>$type);
              $measurement= MeasurementType::model()->find($criteria);
              
              $target[] = $measurement;
                
            }
            
            if($measurement===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "type" => $target,
                                        "measurementtype"=>$types,
                                       )
                           );
                       
                }
                
                
            }else{
               header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "type" => null,
                                        "measurementtype"=>null,
                                       )
                           );
                
            }
            
            
        }
        
        
        
        /**
         * This is the function that list all measurement types assigned to a classification
         */
        public function actionlistAllClassificationMeasurementTypes(){
            
            $model = new ClassificationMeasurementType;
            $classification = $_REQUEST['classification'];
            //$measurement_type_id = $_REQUEST['measurement_type_id'];
                    
            $types = $model->retrieveAllMeasurementTypesAlreadyAssignedToAClassification($classification);
            
            $target = [];
            
            if($types !=null){
                foreach($types as $type){
              $criteria = new CDbCriteria();
              $criteria->select = '*';
              $criteria->condition='id=:id';
              $criteria->params = array(':id'=>$type);
              $measurement= MeasurementType::model()->find($criteria);
              
              $target[] = $measurement;
                
            }
            
            if($measurement===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "type" => $target,
                                        "measurementtype"=>$types,
                                       )
                           );
                       
                }
                
                
            }else{
                 header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "type" => $target,
                                        "measurementtype"=>null,
                                       )
                           );
                
            }
            
            
        }
        
        
        /**
         * This is the function that list category all measurement types
         */
        public function actionlistCategoryMeasurementTypes(){
            
            $model = new Product;
            
            $product_id = $_REQUEST['product_id'];
            
            //get the category_id of this product
            $category_id = $model->getTheCategoryIdOfThisProduct($product_id);
            
            //get all the measurement type of this category
            $types = $this->getAllMeasurementTypesOfThisCategory($category_id);
            
            $target = [];
            //list the measurement types
            foreach($types as $type){
              $criteria = new CDbCriteria();
              $criteria->select = '*';
              $criteria->condition='id=:id';
              $criteria->params = array(':id'=>$type);
              $measurement= MeasurementType::model()->find($criteria);
              
              $target[] = $measurement;
            }
            
             if($measurement===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "type" => $target
                                       
                                       )
                           );
                       
                }
            
        }
        
        
        /**
         * This is the function that gets all measurement types of a category
         */
        public function getAllMeasurementTypesOfThisCategory($category_id){
            $model = new CategoryMeasurementType;
            return $model->retrieveAllMeasurementTypesAlreadyAssignedToACategory($category_id);
        }

       /**
        * This is the function that list all measurement type for this product
        */
        public function actionlistThisProductPreferredMeasurementType(){
            
            $model = new Product;
            
            $product_id = $_REQUEST['product_id'];
            
            //get the preferred measurement type in the market place
            $preferred_type = $this->getThePreferredMeasurementType();
            
            if($preferred_type == 'product_category'){
                //get the category_id of this product
            $category_id = $model->getTheCategoryIdOfThisProduct($product_id);
            
            //get all the measurement type of this category
            $types = $this->getAllMeasurementTypesOfThisCategory($category_id);
                
                
            }else{
                //get the classification of this product
                $classification = $model->getTheClassificationOfThisProduct($product_id);
                
                //get the measurement type of this classification
                $types = $this->getTheMeasurementTypesOfThisClassification($classification);
                
            }
            
            
            
            $target = [];
            //list the measurement types
            foreach($types as $type){
              $criteria = new CDbCriteria();
              $criteria->select = '*';
              $criteria->condition='id=:id';
              $criteria->params = array(':id'=>$type);
              $measurement= MeasurementType::model()->find($criteria);
              
              $target[] = $measurement;
            }
            
             if($measurement===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "type" => $target
                                       
                                       )
                           );
                       
                }
            
            
        }
        
        
         /**
         * This is the function that gets all measurement types of a classification
         */
        public function getTheMeasurementTypesOfThisClassification($classification){
            $model = new ClassificationMeasurementType;
            return $model->retrieveAllMeasurementTypesAlreadyAssignedToAClassification($classification);
        }
        
        
        /**
         * this is the function that gets the preferred measurement type
         */
        public function getThePreferredMeasurementType(){
            
            $model = new GeneralPolicyAndSettings;
            return $model->getThePreferredMeasurementType();
        }
        
        /**
         * This is the function that list a measurement types of all classifications unders a category
         */
        public function actionlistcustomerbasedmeasurementtypesforthiscategory(){
            $model = new GeneralPolicyAndSettings;
            $category = $_REQUEST['category'];
            
            $target = [];
            
            //get all products classifications for this category
            $classifications = $this->getAllProductsClassificationForThisCategory($category);
            $prevailing_measurement_type = $model->getThePreferredMeasurementType();
            
            foreach($classifications as $cls){
            
            if($prevailing_measurement_type == "product_classification"){
                //retrieve all the measurement type of a classification
              $criteria = new CDbCriteria();
              $criteria->select = '*';
              $criteria->condition='classification=:class';
              $criteria->params = array(':class'=>$cls);
              $units= ClassificationMeasurementType::model()->findAll($criteria);
              $data = [];
              foreach($units as $unit){
                  $data[] = $unit['measurement_type_id'];
              }
            }else{
                  //retrieve all the measurement type of a category
              $criteria = new CDbCriteria();
              $criteria->select = '*';
              $criteria->condition='category_id=:catid';
              $criteria->params = array(':catid'=>$category);
              $units= CategoryMeasurementType::model()->findAll($criteria);
              
              foreach($units as $unit){
                  $data[] = $unit['measurement_type_id'];
              }
            }
            
            
            
            foreach($data as $dat){
              $criteria = new CDbCriteria();
              $criteria->select = '*';
              $criteria->condition='id=:id';
              $criteria->params = array(':id'=>$dat);
              $type= MeasurementType::model()->find($criteria);
              $target[] = $type;
            }
            
             
                
            }
           
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "unit"=>$target,
                                    
                    
                            ));
                
                
            
        }
        
        
        /**
         * This is the function that list a measurement types of all classifications unders a category
         */
        public function actionlistcustomerbasedmeasurementtypesforthiscategoryforngadi(){
            $model = new GeneralPolicyAndSettings;
            $category = $_REQUEST['category_id'];
            
            $target = [];
            
            //get all products classifications for this category
            $classifications = $this->getAllProductsClassificationForThisCategoryForNgadi($category);
            $prevailing_measurement_type = $model->getThePreferredMeasurementType();
            
            foreach($classifications as $cls){
            
            if($prevailing_measurement_type == "product_classification"){
                //retrieve all the measurement type of a classification
              $criteria = new CDbCriteria();
              $criteria->select = '*';
              $criteria->condition='classification=:class';
              $criteria->params = array(':class'=>$cls);
              $units= ClassificationMeasurementType::model()->findAll($criteria);
              $data = [];
              foreach($units as $unit){
                  $data[] = $unit['measurement_type_id'];
              }
            }else{
                  //retrieve all the measurement type of a category
              $criteria = new CDbCriteria();
              $criteria->select = '*';
              $criteria->condition='category_id=:catid';
              $criteria->params = array(':catid'=>$category);
              $units= CategoryMeasurementType::model()->findAll($criteria);
              
              foreach($units as $unit){
                  $data[] = $unit['measurement_type_id'];
              }
            }
            
            
            
            foreach($data as $dat){
              $criteria = new CDbCriteria();
              $criteria->select = '*';
              $criteria->condition='id=:id';
              $criteria->params = array(':id'=>$dat);
              $type= MeasurementType::model()->find($criteria);
              $target[] = $type;
            }
            
             
                
            }
           
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "unit"=>$target,
                                    
                    
                            ));
                
                
            
        }
        /**
         * This is the function that gets the classifications for products under a category
         */
        public function getAllProductsClassificationForThisCategory($category){
            $model = new Product;
            return $model->getAllProductsClassificationForThisCategory($category);
            
        }
        
        /**
         * This is the function that gets the classifications for products under a category
         */
        public function getAllProductsClassificationForThisCategoryForNgadi($category){
            $model = new Product;
            return $model->getAllProductsClassificationForThisCategoryForNgadi($category);
            
        }
        
        
         /**
         * This is the function that gets the classifications for products under a product type
         */
        public function getAllProductsClassificationForThisType($type){
            $model = new Product;
            return $model->getAllProductsClassificationForThisType($type);
            
        }
        
        
        /**
         * This is the function that list a measurement types of all classifications unders a category
         */
        public function actionlistcustomerbasedmeasurementtypesforthisproducttype(){
            $model = new GeneralPolicyAndSettings;
            $type = $_REQUEST['type_id'];
            
            $target = [];
            
            //get all products classifications for this category
            //$classifications = $this->getAllProductsClassificationForThisCategoryForNgadi($category);
            $classifications = $this->getAllProductsClassificationForThisType($type);
            $prevailing_measurement_type = $model->getThePreferredMeasurementType();
            
            foreach($classifications as $cls){
            
            if($prevailing_measurement_type == "product_classification"){
                //retrieve all the measurement type of a classification
              $criteria = new CDbCriteria();
              $criteria->select = '*';
              $criteria->condition='classification=:class';
              $criteria->params = array(':class'=>$cls);
              $units= ClassificationMeasurementType::model()->findAll($criteria);
              $data = [];
              foreach($units as $unit){
                  $data[] = $unit['measurement_type_id'];
              }
            }else{
                  //retrieve all the measurement type of a category
              $criteria = new CDbCriteria();
              $criteria->select = '*';
              $criteria->condition='category_id=:catid';
              $criteria->params = array(':catid'=>$category);
              $units= CategoryMeasurementType::model()->findAll($criteria);
              
              foreach($units as $unit){
                  $data[] = $unit['measurement_type_id'];
              }
            }
            
            
            
            foreach($data as $dat){
              $criteria = new CDbCriteria();
              $criteria->select = '*';
              $criteria->condition='id=:id';
              $criteria->params = array(':id'=>$dat);
              $type= MeasurementType::model()->find($criteria);
              $target[] = $type;
            }
            
             
                
            }
           
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "unit"=>$target,
                                    
                    
                            ));
                
                
            
        }
}
