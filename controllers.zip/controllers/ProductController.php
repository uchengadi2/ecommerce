<?php

class ProductController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update','listProductTypeMerchantProducts','modifyproduct','addnewproduct','deleteoneproduct','listAllMerchantProducts',
                                    'listAllProducts','listAllWarehouseProducts','listThisMerchantAllProducts'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	/**
         * This is the function that list all products of a product type and belonging to a merchant
         */
        public function actionlistProductTypeMerchantProducts(){
            $model = new User;
            
            $user_id = Yii::app()->user->id;
            
            $merchant_id = $model->getTheMerchantIdOfThisUser($user_id);
            
            $type_id = $_REQUEST['type_id'];
            
             $criteria = new CDbCriteria();
              $criteria->select = '*';
              $criteria->condition='product_type_id=:typeid and merchant_id=:merid';
              $criteria->params = array(':typeid'=>$type_id,':merid'=>$merchant_id);
              $products= Product::model()->findAll($criteria);
              if($products===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                         header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "product" => $products,
                                    "merchant_id"=>$merchant_id
                                   
                    
                            ));
                       
                       
                }
        }
        
        
        /**
         * This is the function that adds new product to a product type
         */
        public function actionaddnewproduct(){
            $model = new Product;
            $user_id = Yii::app()->user->id;
            $merchant_id = $model->getTheMerchantIdOfThisUser($user_id);
            
            $model->product_type_id = $_POST['product_type_id'];
            $model->name  = $_POST['name'];
            if(isset($_POST['description'])){
                $model->description = $_POST['description'];
            }
            $model->merchant_id = $merchant_id;
            $model->classification = $_POST['classification'];
            $model->create_time = new CDbExpression('NOW()');
            $model->create_user_id = Yii::app()->user->id;
            
             $icon_error_counter = 0;
                
                 if($_FILES['icon']['name'] != ""){
                    if($model->isImageTypeAndSizeLegal()){
                        
                       $icon_filename = $_FILES['icon']['name'];
                      //$icon_size = $_FILES['flag']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $icon_filename = NULL;   
                   //$icon_size = 0;
             
                }//end of the if icon is empty statement
                
                
                //front view image
                if($_FILES['product_front_view']['name'] != ""){
                    if($model->isFrontImageTypeAndSizeLegal()){
                        
                       $front_filename = $_FILES['product_front_view']['name'];
                      //$icon_size = $_FILES['flag']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $front_filename = NULL;   
                   //$icon_size = 0;
             
                }//end of the if icon is empty statement
                
                
                 //right side view image
                if($_FILES['product_right_side_view']['name'] != ""){
                    if($model->isRightImageTypeAndSizeLegal()){
                        
                       $right_filename = $_FILES['product_right_side_view']['name'];
                      //$icon_size = $_FILES['flag']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $right_filename = NULL;   
                   //$icon_size = 0;
             
                }//end of the if icon is empty statement
                
                
                
                //top view image
                if($_FILES['product_top_view']['name'] != ""){
                    if($model->isTopImageTypeAndSizeLegal()){
                        
                       $top_filename = $_FILES['product_top_view']['name'];
                      //$icon_size = $_FILES['flag']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $top_filename = NULL;   
                   //$icon_size = 0;
             
                }//end of the if icon is empty statement
                
                
                
                //inside view image
                if($_FILES['product_inside_view']['name'] != ""){
                    if($model->isInsideImageTypeAndSizeLegal()){
                        
                       $inside_filename = $_FILES['product_inside_view']['name'];
                      //$icon_size = $_FILES['flag']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $inside_filename = NULL;   
                   //$icon_size = 0;
             
                }//end of the if icon is empty statement
                
                
                //back view image
                if($_FILES['product_back_view']['name'] != ""){
                    if($model->isBackImageTypeAndSizeLegal()){
                        
                       $back_filename = $_FILES['product_back_view']['name'];
                      //$icon_size = $_FILES['flag']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $back_filename = NULL;   
                   //$icon_size = 0;
             
                }//end of the if icon is empty statement
                
                
                      //left side view image
                if($_FILES['product_left_side_view']['name'] != ""){
                    if($model->isLeftImageTypeAndSizeLegal()){
                        
                       $left_filename = $_FILES['product_left_side_view']['name'];
                      //$icon_size = $_FILES['flag']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $left_filename = NULL;   
                   //$icon_size = 0;
             
                }//end of the if icon is empty statement
                
                
                
                   //bottom view image
                if($_FILES['product_bottom_view']['name'] != ""){
                    if($model->isBottomImageTypeAndSizeLegal()){
                        
                       $bottom_filename = $_FILES['product_bottom_view']['name'];
                      //$icon_size = $_FILES['flag']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $bottom_filename = NULL;   
                   //$icon_size = 0;
             
                }//end of the if icon is empty statement
                
                
                if($icon_error_counter ==0){
                   if($model->validate()){
                           $model->icon = $model->moveTheIconToItsPathAndReturnTheFilename($model,$icon_filename);
                           $model->product_front_view = $model->moveTheFrontImageToItsPathAndReturnTheFilename($model,$front_filename);
                           $model->product_right_side_view = $model->moveTheRightImageToItsPathAndReturnTheFilename($model,$right_filename);
                           $model->product_top_view = $model->moveTheTopToItsPathAndReturnTheFilename($model,$top_filename);
                           $model->product_inside_view = $model->moveTheInsideImageToItsPathAndReturnTheFilename($model,$inside_filename);
                           $model->product_back_view = $model->moveTheBackImageToItsPathAndReturnTheFilename($model,$back_filename);
                           $model->product_left_side_view = $model->moveTheLeftImageToItsPathAndReturnTheFilename($model,$left_filename);
                           $model->product_bottom_view = $model->moveTheBottomImageToItsPathAndReturnTheFilename($model,$bottom_filename);
                           
                           
                       if($model->save()) {
                        
                                $msg = "'$model->name' product was added successful";
                                 header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                 "success" => mysql_errno() == 0,
                                  "msg" => $msg)
                            );
                         
                        }else{
                            //delete all the moved files in the directory when validation error is encountered
                            $msg = 'Validaion Error: Check your file fields for correctness';
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                               );
                          }
                            }else{
                                
                                //delete all the moved files in the directory when validation error is encountered
                            $msg = "Validation Error: '$model->name' product  was not added";
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                            );
                          }
                   }elseif($icon_error_counter > 0){
                        $msg = "Please check the image you uploaded and ensure that they meet the requirements. Note that the images must have a minimum size of 1000px by 1000px and they must either be in  .png or .jpg file format";
                            header('Content-Type: application/json');
                                    echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                    "msg" => $msg)
                            );
                         
                        } 
            
            
        }
        
        
        
        
         /**
         * This is the function that updates a product info
         */
        public function actionmodifyproduct(){
            
            $_id = $_POST['id'];
             $model=Product::model()->findByPk($_id);
            $merchant_id = $_POST['merchant_id'];
            
            $model->product_type_id = $_POST['product_type_id'];
            $model->name  = $_POST['name'];
            if(isset($_POST['description'])){
                $model->description = $_POST['description'];
            }
            $model->merchant_id = $merchant_id;
            $model->classification = $_POST['classification'];
            $model->create_time = new CDbExpression('NOW()');
            $model->create_user_id = Yii::app()->user->id;
            
             $icon_error_counter = 0;
                
                 if($_FILES['icon']['name'] != ""){
                    if($model->isImageTypeAndSizeLegal()){
                        
                       $icon_filename = $_FILES['icon']['name'];
                      //$icon_size = $_FILES['flag']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $icon_filename = $model->retrieveThePreviousIconImage($_id);   
                   //$icon_size = 0;
             
                }//end of the if icon is empty statement
                
                
                //front view image
                if($_FILES['product_front_view']['name'] != ""){
                    if($model->isFrontImageTypeAndSizeLegal()){
                        
                       $front_filename = $_FILES['product_front_view']['name'];
                      //$icon_size = $_FILES['flag']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $front_filename = $model->retrieveThePreviousFrontImage($_id);  
                   //$icon_size = 0;
             
                }//end of the if icon is empty statement
                
                
                 //right side view image
                if($_FILES['product_right_side_view']['name'] != ""){
                    if($model->isRightImageTypeAndSizeLegal()){
                        
                       $right_filename = $_FILES['product_right_side_view']['name'];
                      //$icon_size = $_FILES['flag']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $right_filename = $model->retrieveThePreviousRightImage($_id);   
                   //$icon_size = 0;
             
                }//end of the if icon is empty statement
                
                
                
                //top view image
                if($_FILES['product_top_view']['name'] != ""){
                    if($model->isTopImageTypeAndSizeLegal()){
                        
                       $top_filename = $_FILES['product_top_view']['name'];
                      //$icon_size = $_FILES['flag']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $top_filename = $model->retrieveThePreviousTopImage($_id); 
                   //$icon_size = 0;
             
                }//end of the if icon is empty statement
                
                
                
                //inside view image
                if($_FILES['product_inside_view']['name'] != ""){
                    if($model->isInsideImageTypeAndSizeLegal()){
                        
                       $inside_filename = $_FILES['product_inside_view']['name'];
                      //$icon_size = $_FILES['flag']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $inside_filename = $model->retrieveThePreviousInsideImage($_id); 
                   //$icon_size = 0;
             
                }//end of the if icon is empty statement
                
                
                //back view image
                if($_FILES['product_back_view']['name'] != ""){
                    if($model->isBackImageTypeAndSizeLegal()){
                        
                       $back_filename = $_FILES['product_back_view']['name'];
                      //$icon_size = $_FILES['flag']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $back_filename = $model->retrieveThePreviousBackImage($_id); 
                   //$icon_size = 0;
             
                }//end of the if icon is empty statement
                
                
                      //left side view image
                if($_FILES['product_left_side_view']['name'] != ""){
                    if($model->isLeftImageTypeAndSizeLegal()){
                        
                       $left_filename = $_FILES['product_left_side_view']['name'];
                      //$icon_size = $_FILES['flag']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $left_filename =$model->retrieveThePreviousLeftImage($_id); 
                   //$icon_size = 0;
             
                }//end of the if icon is empty statement
                
                
                
                   //bottom view image
                if($_FILES['product_bottom_view']['name'] != ""){
                    if($model->isBottomImageTypeAndSizeLegal()){
                        
                       $bottom_filename = $_FILES['product_bottom_view']['name'];
                      //$icon_size = $_FILES['flag']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $bottom_filename = $model->retrieveThePreviousBottonImage($_id); 
                   //$icon_size = 0;
             
                }//end of the if icon is empty statement
                
                
                if($icon_error_counter ==0){
                   if($model->validate()){
                           $model->icon = $model->moveTheIconToItsPathAndReturnTheFilename($model,$icon_filename);
                           $model->product_front_view = $model->moveTheFrontImageToItsPathAndReturnTheFilename($model,$front_filename);
                           $model->product_right_side_view = $model->moveTheRightImageToItsPathAndReturnTheFilename($model,$right_filename);
                           $model->product_top_view = $model->moveTheTopToItsPathAndReturnTheFilename($model,$top_filename);
                           $model->product_inside_view = $model->moveTheInsideImageToItsPathAndReturnTheFilename($model,$inside_filename);
                           $model->product_back_view = $model->moveTheBackImageToItsPathAndReturnTheFilename($model,$back_filename);
                           $model->product_left_side_view = $model->moveTheLeftImageToItsPathAndReturnTheFilename($model,$left_filename);
                           $model->product_bottom_view = $model->moveTheBottomImageToItsPathAndReturnTheFilename($model,$bottom_filename);
                           
                           
                       if($model->save()) {
                        
                                $msg = "'$model->name' product was updated successful";
                                 header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                 "success" => mysql_errno() == 0,
                                  "msg" => $msg)
                            );
                         
                        }else{
                            //delete all the moved files in the directory when validation error is encountered
                            $msg = 'Validaion Error: Check your file fields for correctness';
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                               );
                          }
                            }else{
                                
                                //delete all the moved files in the directory when validation error is encountered
                            $msg = "Validation Error: '$model->name' product  was not updated";
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                            );
                          }
                   }elseif($icon_error_counter > 0){
                        $msg = "Please check the image you uploaded and ensure that they meet the requirements. Note that the images must have a minimum size of 1000px by 1000px and they must either be in  .png or .jpg file format";
                            header('Content-Type: application/json');
                                    echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                    "msg" => $msg)
                            );
                         
                        } 
            
            
        }
        
        
        
        /**
         * This is the function that deletes a product from a product ty[e
         */
        public function actiondeleteoneproduct(){
            
             $_id = $_POST['id'];
             $model=Product::model()->findByPk($_id);
            
            if($model->isTheRemovalOfProductImagesASuccess($_id)){
               
            $name = $_REQUEST['name'];
            if($model === null){
                $data['success'] = 'undefined';
                $data['msg'] = 'No such record exist';
                header('Content-Type: application/json');
                echo CJSON::encode($data);
                                      
            }else if($model->delete()){
                    $data['success'] = 'true';
                    $data['msg'] = "'$name' was successfully deleted";
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
            } else {
                    $data['success'] = 'false';
                    $data['msg'] = 'deletion was unsuccessful';
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
                            
                }
                
            }else{
                $data['success'] = 'false';
                    $data['msg'] = 'deletion was unsuccessful';
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
            }
        }
        
        
        
        /**
         * This is the function that list all merchants products
         */
        public function actionlistAllMerchantProducts(){
            
            $model = new Product;
            
            $merchant_id = $_REQUEST['merchant_id'];
             $criteria = new CDbCriteria();
              $criteria->select = '*';
              $criteria->condition='merchant_id=:merid';
              $criteria->params = array(':merid'=>$merchant_id);
              $products= Product::model()->findAll($criteria);
              
              if($products===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                         header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "product" => $products,
                                    "merchant_id"=>$merchant_id
                                   
                    
                            ));
                       
                       
                }
              
            
        }
        
        
        
        /**
         * This is the function that list all products
         */
        public function actionlistAllProducts(){
            
             $model = new Product;
            
             $products = Product::model()->findAll();
                if($products===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                        header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "product" => $products,
                                   
                    
                            ));
                       
                }
        }
        
        
        /**
         * This is the function that list all products in a warehouse
         */
        public function actionlistAllWarehouseProducts(){
            $model = new Inventory;
            $warehouse_id = $_REQUEST['warehouse_id'];
            
            //get all the products in this warehouse
            $products = $model->getAllProductsInThisWarehouse($warehouse_id);
            $target = [];
            foreach($products as $product){
               $criteria = new CDbCriteria();
              $criteria->select = '*';
              $criteria->condition='id=:id';
              $criteria->params = array(':id'=>$product);
              $prod= Product::model()->find($criteria);
              $target[] = $prod;
           
            }
            
            if($products===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else{
                        header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "product" => $target,
                                   
                    
                            ));
                       
                }
               
        }
        
        
        
         /**
         * This is the function that list all merchants products
         */
        public function actionlistThisMerchantAllProducts(){
            
            $model = new User;
            $user_id = Yii::app()->user->id;
            $merchant_id = $model->getTheMerchantIdOfThisUser($user_id);
            
             $criteria = new CDbCriteria();
              $criteria->select = '*';
              $criteria->condition='merchant_id=:merid';
              $criteria->params = array(':merid'=>$merchant_id);
              $products= Product::model()->findAll($criteria);
              
              if($products===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                         header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "product" => $products,
                                    "merchant_id"=>$merchant_id
                                   
                    
                            ));
                       
                       
                }
              
            
        }
}
