<?php

class PromotionController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update','addpromotiontoproductprice','modifyproductpricepromotion','removepromotionfromproductprice',
                                    'retrievethepromotiononthisprice','listAllPromotions','retrievethispricepromotions','activatepricepromotion'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	
        
        /**
         * This is the function that promotion to a product price
         */
        public function actionaddpromotiontoproductprice(){
            
            $model = new Promotion;
            
            $price_id = $_REQUEST['price_id'];
           // $inventory_id = $_REQUEST['inventory_id'];
                        
            $model->pricing_id = $price_id;
            $model->type= $_REQUEST['type'];
            
            if(isset($_REQUEST['condition'])){
                $model->condition = $_REQUEST['condition'];
            }
            $model->x_quantity = $_REQUEST['x_quantity'];
            $model->start_date = date("Y-m-d H:i:s", strtotime($_POST['start_date']));
            $model->end_date = date("Y-m-d H:i:s", strtotime($_POST['end_date']));
            
            if($_REQUEST['type'] =="buy_x_get_y_free"){
                $model->y_product = $_REQUEST['y_product'];
                $model->y_product_quantity = $_REQUEST['y_product_quantity'];
            }else if($_REQUEST['type'] =="buy_x_get_x_free"){
                $model->y_quantity = $_REQUEST['y_quantity'];
                
            }else if($_REQUEST['type'] =="buy_x_at_y_quantity"){
                $model->y_quantity = $_REQUEST['y_quantity'];
            }else if($_REQUEST['type'] =="buy_x_at_discount_of"){
                $model->y_percentage = $_REQUEST['y_percentage'];
            }else if($_REQUEST['type'] =="buy_x_at_price_percentage_off"){
                 $model->y_percentage = $_REQUEST['y_percentage'];
            }
            
            $model->available_cities =  $_REQUEST['available_cities'];
            $model->status="inactive";
            
          if($model->save()){
                    //register a default associate promoton
                    $this->registerTheDefaultAssociatePromotion($model->id);
                $msg = "This product price promotion is created successfully";
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg,
                                        )
                           );
            }else{
                $msg = "Attempt to create this price pomotion was not successful";
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg)
                           );
            }
                
                
           
        }
        
        
         /**
         * this is the function that sets the deafult associate promotion for a promotion
         */
        public function registerTheDefaultAssociatePromotion($id){
            $model = new AssociatedPromotion;
            return $model->registerTheDefaultAssociatePromotion($id);
        }
        
        
        
         /**
         * This is the function that updates the promotion information on a product price
         */
        public function actionmodifyproductpricepromotion(){
            
           
            
            $id = $_REQUEST['id'];
                    
           $model= Promotion::model()->findByPk($id);
            $model->type= $_REQUEST['type'];
             //$model->pricing_id= $price_id;
                       
            if(isset($_REQUEST['condition'])){
                $model->condition = $_REQUEST['condition'];
            }
            $model->x_quantity = $_REQUEST['x_quantity'];
            $model->start_date = date("Y-m-d H:i:s", strtotime($_POST['start_date']));
            $model->end_date = date("Y-m-d H:i:s", strtotime($_POST['end_date']));
            
            if($_REQUEST['type'] =="buy_x_get_y_free"){
                $model->y_product = $_REQUEST['y_product'];
                $model->y_product_quantity = $_REQUEST['y_product_quantity'];
            }else if($_REQUEST['type'] =="buy_x_get_x_free"){
                $model->y_quantity = $_REQUEST['y_quantity'];
                
            }else if($_REQUEST['type'] =="buy_x_at_y_quantity"){
                $model->y_quantity = $_REQUEST['y_quantity'];
            }else if($_REQUEST['type'] =="buy_x_at_discount_of"){
                $model->y_percentage = $_REQUEST['y_percentage'];
            }else if($_REQUEST['type'] =="buy_x_at_price_percentage_off"){
                 $model->y_percentage = $_REQUEST['y_percentage'];
            }
            
            $model->available_cities = $_REQUEST['available_cities']; 
           
                if($model->save()){
                $msg = "This product price promotion is updated successfully";
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg,
                                        "promotion"=>$model,
                                       )
                           );
            }else{
                $msg = "Attempt to update this price pomotion was not successful";
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg)
                           );
            }
                
                
           
        }
        
        
        
        
        /**
         * This is the function that removes  promotion on a product price
         */
        public function actionremovepromotionfromproductprice(){
                     
            
            $price_id = $_REQUEST['price_id'];
                                   
            if($this->isThisPriceAlreadyWithAPromotion($price_id)){
                //get the ptomotion id 
              $promotion_id = $this->getThePromotionIdOfThisPricing($price_id); 
              
               $model= Promotion::model()->findByPk($promotion_id);
               if($this->isTheAssociatePromotionsRemovalASuccess($promotion_id)){
              
                   if($model->delete()){
                       //register a new none dummy promotion for this pricing
                       $this->registerADummyPromotionForThisPricing($price_id);
                $msg = "This product price promotion is deleted successfully";
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg)
                           );
            }else{
                $msg = "Attempt to delete this price pomotion was not successful";
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg)
                           );
            }
                   
               }else{
                   $msg = "Please first remove the associate promotions of this promotion and try again";
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg,
                                        )
                           );
               }
            
                
                
            }else{
                $msg = "This price do not have any promotion on it, therefor the request is ignored";
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg)
                           );
                
            }
        }
        
        
        
        /**
         * This is the function that registers a dummy promotion for a pricing
         */
        public function registerADummyPromotionForThisPricing($price_id){
            $model = new Promotion;
            
            if($model->isDummyPromotionNeededForThisPricing($price_id)){
                $model->pricing_id = $price_id;
                $model->type = "none";
            
            if($model->save()){
                //register this promotion dummy associate promotio
                $this->regiserDummyAssociatePromotionForThisPromotion($model->id);
                return true;
            }else{
                return false;
            }
                
                
            }else{
                return false;
            }
            
        }
        
        
        /**
         * This is the function that registers a dummy assciate promotion
         */
        public function regiserDummyAssociatePromotionForThisPromotion($promotion_id){
            $model = new AssociatedPromotion;
            return $model->regiserDummyAssociatePromotionForThisPromotion($promotion_id);
        }
        
        
        /**
         * This is the function that confirms if the removel of associate promotions are a success
         */
        public function isTheAssociatePromotionsRemovalASuccess($promotion_id){
            $model = new AssociatedPromotion;
            return $model->isTheAssociatePromotionsRemovalASuccess($promotion_id);
        }
        
        /**
         * This is the function tat confirms if a price has a promotion on it
         */
        public function isThisPriceAlreadyWithAPromotion($price_id){
            $model = new Promotion;
            return $model->isThisPriceAlreadyWithAPromotion($price_id);
        }
        
        
        /**
         * This is the function that gets a promotion id of a pricing
         */
        public function getThePromotionIdOfThisPricing($price_id){
            $model = new Promotion;
            return $model->getThePromotionIdOfThisPricing($price_id);
        }
        
        
        /**
         * This is the function that retrieves the details of a price promotion
         */
        public function actionretrievethepromotiononthisprice(){
            $model = new Promotion;
            
            $pricing_id = $_REQUEST['price_id'];
            
            $criteria = new CDbCriteria();
              $criteria->select = '*';
              $criteria->condition='pricing_id=:priceid';
              $criteria->params = array(':priceid'=>$pricing_id);
              $promotion= Promotion::model()->find($criteria);
              
              header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "promotion" =>$promotion
                                       
                                       )
                           );
                       
        }
        
        
        
        
         /**
         * This is the function that retrieves the details of a price promotions
         */
        public function actionretrievethispricepromotions(){
            $model = new Promotion;
            
            $pricing_id = $_REQUEST['price_id'];
            
            $criteria = new CDbCriteria();
              $criteria->select = '*';
              $criteria->condition='pricing_id=:priceid';
              $criteria->params = array(':priceid'=>$pricing_id);
              $promotion= Promotion::model()->findAll($criteria);
              
              header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "promotion" =>$promotion
                                       
                                       )
                           );
                       
        }
        
        
        
        
         /**
         * This is the function that list all promotions
         */
        public function actionlistAllPromotions(){
            $promotion = Promotion::model()->findAll();
               header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "promotion" => $promotion,
                                   
                    
                            ));
        }
        
        
        /**
         * This is the function that activates a promotion
         */
        public function actionactivatepricepromotion(){
            $id = $_REQUEST['id'];
            $model= Promotion::model()->findByPk($id);
             $pricing_id = $_REQUEST['pricing_id'];
             $type = $_REQUEST['type'];
             
             if($type != 'none'){
                 if($this->isTheDeactivationOfAllPricePromotionASuccess($pricing_id)){
                 $model->status="active";
                 
                if($model->save()){
                $msg = "This promotion is activated successfully";
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg,
                                        
                                       )
                           );
            }else{
                $msg = "Attempt to activate this price pomotion was not successful";
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                           );
            }
                 
             }else{
                  $msg = "Could not perform this request. Please contact customers service for assistance";
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                           );
             }
                 
                 
             }else{
                 $msg = "You cannot activate a promotion with a 'NONE' type";
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                           );
                 
             }
             
             
             
            
        }
        
        
        /**
         * This is the function that first deactivates all price promotions
         */
        public function isTheDeactivationOfAllPricePromotionASuccess($pricing_id){
            $model = new Promotion;
            return $model->isTheDeactivationOfAllPricePromotionASuccess($pricing_id);
        }
       
}
