<?php

class MerchantController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view','addthisnewmerchant'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update','deleteonemerchant','addnewmerchant','modifymerchant','listAllMerchants','listAllMerchantsOnWhitelist',
                                    'retrievemerchantdetails'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

        
        /**
         * This is the function that list all merchants on the platform
         */
        public function actionlistAllMerchants(){
            
            $model = new Merchant;
            
             $merchant = Merchant::model()->findAll();
                if($merchant===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                        header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "merchant" => $merchant,
                                   
                    
                            ));
                       
                }
        }
	
        
        
         /**
         * This is the function that adds new merchant
         */
        public function actionaddnewmerchant(){
            
            $model=new Merchant;

		
		$model->name = $_POST['name'];
               if(isset($_POST['email'])){
                   $model->email = $_POST['email']; 
                }
                 if(isset($_POST['address'])){
                   $model->address = $_POST['address']; 
                }
                 if(isset($_POST['phone_number'])){
                   $model->phone_number = $_POST['phone_number']; 
                }
                 if(isset($_POST['banker'])){
                   $model->banker = $_POST['banker']; 
                }
                 if(isset($_POST['account_number'])){
                   $model->account_number = $_POST['account_number']; 
                }
                if(isset($_POST['account_title'])){
                   $model->account_title = $_POST['account_title']; 
                }
                if(isset($_POST['bank_swift_code'])){
                   $model->bank_swift_code = $_POST['bank_swift_code']; 
                }
                 if(isset($_POST['tax_identification_pin'])){
                   $model->tax_identification_pin = $_POST['tax_identification_pin']; 
                }
                if(isset($_POST['vat_number'])){
                   $model->vat_number = $_POST['vat_number']; 
                }
                if(isset($_POST['contact_person_name'])){
                   $model->contact_person_name = $_POST['contact_person_name']; 
                }
                if(isset($_POST['contact_person_mobile_number'])){
                   $model->contact_person_mobile_number = $_POST['contact_person_mobile_number']; 
                }
                if(isset($_POST['contact_person_email'])){
                   $model->contact_person_email = $_POST['contact_person_email']; 
                }
                if(isset($_POST['merchant_type'])){
                   $model->merchant_type = $_POST['merchant_type']; 
                }
                $model->merchantid = $model->generateThisMerchantID();
               if(isset($_POST['description'])){
                   $model->description = $_POST['description']; 
                }
                
                $model->create_time = new CDbExpression('NOW()');
                $model->create_user_id = Yii::app()->user->id;
                if($model->save()){
                         // $result['success'] = 'true';
                          $msg = 'Successfully created new merchant';
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                        "msg" => $msg)
                           );
                     }else {
                         //$result['success'] = 'false';
                         $msg = 'New merchant creation was unsuccessful';
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                           );
                    } 
            
        }
        
        
        
        /**
         * This is the function that modifies merchant info
         */
        public function actionmodifymerchant(){
            
           $_id = $_POST['id'];
            
            $model= Merchant::model()->findByPk($_id);
		$model->name = $_POST['name'];
               if(isset($_POST['email'])){
                   $model->email = $_POST['email']; 
                }
                 if(isset($_POST['address'])){
                   $model->address = $_POST['address']; 
                }
                 if(isset($_POST['phone_number'])){
                   $model->phone_number = $_POST['phone_number']; 
                }
                 if(isset($_POST['banker'])){
                   $model->banker = $_POST['banker']; 
                }
                 if(isset($_POST['account_number'])){
                   $model->account_number = $_POST['account_number']; 
                }
                if(isset($_POST['account_title'])){
                   $model->account_title = $_POST['account_title']; 
                }
                if(isset($_POST['bank_swift_code'])){
                   $model->bank_swift_code = $_POST['bank_swift_code']; 
                }
                 if(isset($_POST['tax_identification_pin'])){
                   $model->tax_identification_pin = $_POST['tax_identification_pin']; 
                }
                if(isset($_POST['vat_number'])){
                   $model->vat_number = $_POST['vat_number']; 
                }
                if(isset($_POST['contact_person_name'])){
                   $model->contact_person_name = $_POST['contact_person_name']; 
                }
                if(isset($_POST['contact_person_mobile_number'])){
                   $model->contact_person_mobile_number = $_POST['contact_person_mobile_number']; 
                }
                if(isset($_POST['contact_person_email'])){
                   $model->contact_person_email = $_POST['contact_person_email']; 
                }
                if(isset($_POST['merchant_type'])){
                   $model->merchant_type = $_POST['merchant_type']; 
                }
                $model->merchantid = $_POST['merchantid'];
               if(isset($_POST['description'])){
                   $model->description = $_POST['description']; 
                }
                
                $model->update_time = new CDbExpression('NOW()');
                $model->update_user_id = Yii::app()->user->id;
                if($model->save()){
                         // $result['success'] = 'true';
                          $msg = 'Successfully updated this merchant information';
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                        "msg" => $msg)
                           );
                     }else {
                         //$result['success'] = 'false';
                         $msg = 'Merchant update was unsuccessful';
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                           );
                    } 
            
        }
        
        
        
        /**
	 * Deletes a particular model instance
	 * 
         **/
	public function actiondeleteonemerchant()
	{
            
            $_id = $_REQUEST['id'];
            $model= Merchant::model()->findByPk($_id);
            
            //get the contractor name
            $merchant_name = $_REQUEST['name'];
            
            if($model === null){
                $data['success'] = 'undefined';
                $data['msg'] = 'No such record exist';
                header('Content-Type: application/json');
                echo CJSON::encode($data);
                                      
            }else if($model->delete()){
                    $data['success'] = 'true';
                    $data['msg'] = "'$merchant_name' merchant was successfully deleted";
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
            } else {
                    $data['success'] = 'false';
                    $data['msg'] = 'deletion unsuccessful';
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
                            
                }
	}
        
        
        /**
         * This is the function that list all merchants in the whitelist
         */
        public function actionlistAllMerchantsOnWhitelist(){
            
            $model = new MerchantWhitelist;
            $merchants = $model->retrieveAllMerchantsOnTheWhiteList();
            
            $target = [];
            
            foreach($merchants as $merch){
              $criteria = new CDbCriteria();
              $criteria->select = '*';
              $criteria->condition='id=:id';
              $criteria->params = array(':id'=>$merch);
              $merchant= Merchant::model()->find($criteria);
              
              $target[] = $merchant;
                
            }
            
            if($merchants===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                        "merchant" => $target,
                                       )
                           );
                       
                }
        }
        
        /**
         * This is the function that retrieves merchant details
         * 
         */
        public function actionretrievemerchantdetails(){
            
            $model = new User;
            
            $user_id = Yii::app()->user->id;
            
            $merchant_id = $model->getTheMerchantIdOfThisUser($user_id);
            
              $criteria = new CDbCriteria();
              $criteria->select = '*';
              $criteria->condition='id=:id';
              $criteria->params = array(':id'=>$merchant_id);
              $merchant= Merchant::model()->find($criteria);
              
               header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                        "merchant" => $merchant
                                       
                                       )
                           );
        }
        
        
         /**
         * This is the function that adds new merchant
         */
        public function actionaddthisnewmerchant(){
            
            $model=new Merchant;

		
		$model->name = $_POST['name'];
               if(isset($_POST['email'])){
                   $model->email = $_POST['email']; 
                }
                 if(isset($_POST['address'])){
                   $model->address = $_POST['address']; 
                }
                 if(isset($_POST['phone_number'])){
                   $model->phone_number = $_POST['phone_number']; 
                }
                 if(isset($_POST['banker'])){
                   $model->banker = $_POST['banker']; 
                }
                 if(isset($_POST['account_number'])){
                   $model->account_number = $_POST['account_number']; 
                }
                if(isset($_POST['account_title'])){
                   $model->account_title = $_POST['account_title']; 
                }
                if(isset($_POST['bank_swift_code'])){
                   $model->bank_swift_code = $_POST['bank_swift_code']; 
                }
                 if(isset($_POST['tax_identification_pin'])){
                   $model->tax_identification_pin = $_POST['tax_identification_pin']; 
                }
                if(isset($_POST['vat_number'])){
                   $model->vat_number = $_POST['vat_number']; 
                }
                if(isset($_POST['contact_person_name'])){
                   $model->contact_person_name = $_POST['contact_person_name']; 
                }
                if(isset($_POST['contact_person_mobile_number'])){
                   $model->contact_person_mobile_number = $_POST['contact_person_mobile_number']; 
                }
                if(isset($_POST['contact_person_email'])){
                   $model->contact_person_email = $_POST['contact_person_email']; 
                }
                if(isset($_POST['merchant_type'])){
                   $model->merchant_type = $_POST['merchant_type']; 
                }
                $model->merchantid = $model->generateThisMerchantID();
               if(isset($_POST['description'])){
                   $model->description = $_POST['description']; 
                }
                
                $model->create_time = new CDbExpression('NOW()');
                $model->create_user_id = Yii::app()->user->id;
                if($model->save()){
                         // $result['success'] = 'true';
                          $msg = "You have successfully registerred this merchant and your Merchant Id is '$model->merchantid'. We will be communicating with you shortly";
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                        "msg" => $msg)
                           );
                     }else {
                         //$result['success'] = 'false';
                         $msg = 'This merchant could not be registered. Please contact customer service';
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                           );
                    } 
            
        }
      
}
