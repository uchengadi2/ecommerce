<?php

class CityController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view','listAllCities','listAllCitiesInThisState','listAllCitiesOnWhitelist'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update','listAllCitiesInThisState','deleteonecity','addnewcity','updatecity','listAllCities','listAllCitiesOnWhitelist',
                                    'listallcitiesinneighbourhood','setintracitydeliveryrates','listallCitiesWithPackagesForDeliveryForThisCourier'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	/**
         * This is the function that list all states in a country
         */
        public function actionlistAllCitiesInThisState(){
            $model = new City;
            
            $state_id = $_REQUEST['state_id'];
            
              $criteria = new CDbCriteria();
              $criteria->select = '*';
              $criteria->condition='state_id=:id';
              $criteria->params = array(':id'=>$state_id);
              $city= City::model()->findAll($criteria);
              if($city===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                         header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "city" => $city,
                                   
                    
                            ));
                       
                       
                }
            
        }
        
        
        /**
         * This is the function that adds new city to a state
         */
        public function actionaddnewcity(){
            
            $model = new City;
            $model->name = $_POST['name'];
                $model->state_id = $_POST['state_id'];
               if(isset($_POST['description'])){
                   $model->description = $_POST['description']; 
                }
                
                $model->create_time = new CDbExpression('NOW()');
                $model->create_user_id = Yii::app()->user->id;
                if($model->save()){
                         // $result['success'] = 'true';
                          $msg = 'Successfully created new city';
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg)
                           );
                     }else {
                         //$result['success'] = 'false';
                         $msg = 'New city creation was unsuccessful';
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                           );
                    } 
            
        }
        
        
        
        /**
         * This is the function that modifies ezisting city information
         */
        public function actionupdatecity(){
            
            //get the country id
            $state= $_POST['state_id'];
         
            $_id = $_POST['id'];
            
            $model=City::model()->findByPk($_id);
            $model->name = $_POST['name'];
            $model->state_id = $state;
           if(isset($_POST['description'])){
                   $model->description = $_POST['description']; 
                }
                
            $model->update_time = new CDbExpression('NOW()');
            //$model->update_user_id = Yii::app()->user->id;
            if($model->save()){
                       // $data['success'] = 'true';
                        $msg = 'City information successfully updated';
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg)
                           );
                }else {
                   // $data['success'] = 'false';
                    $msg = 'City information update was unsuccessful';
                     header('Content-Type: application/json');
                     echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                           );
                }
        }
        
        
        
        /**
	 * Deletes a particular model instance
	 * 
         **/
	public function actiondeleteonecity()
	{
            
            $_id = $_POST['id'];
            $model=City::model()->findByPk($_id);
            
             //get the name of this city
            $city_name = $model->getTheNameOfThisCity($_id);
            
            if($model === null){
                $data['success'] = 'undefined';
                $data['msg'] = 'No such record exist';
                header('Content-Type: application/json');
                echo CJSON::encode($data);
                                      
            }else if($model->delete()){
                    $data['success'] = 'true';
                    $data['msg'] = "'$city_name' city is successfully deleted";
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
            } else {
                    $data['success'] = 'false';
                    $data['msg'] = 'deletion unsuccessful';
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
                            
                }
	}
        
        
        /**
         * This is the function that list all cities in the marketplace
         */
        public function actionlistAllCities(){
            $cities = City::model()->findAll();
                if($cities===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "city" => $cities)
                           );
                       
                }
        }
        
        
        /**
         * This is the function that list all cities in a whitelist
         */
        public function actionlistAllCitiesOnWhitelist(){
            
            $model = new CityWhitelist;
            $cities = $model->retrieveAllCitiesOnTheWhiteList();
            
            $target = [];
            
            foreach($cities as $cityid){
              $criteria = new CDbCriteria();
              $criteria->select = '*';
              $criteria->condition='id=:id';
              $criteria->params = array(':id'=>$cityid);
              $city= City::model()->find($criteria);
              
              $target[] = $city;
                
            }
            
            if($cities===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                       header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "city" => $target,
                                        "cities"=>$cities)
                           );
                       
                }
        }
        
        
        /**
         * This is the function that list all cities in a neighbourhood
         */
        public function actionlistallcitiesinneighbourhood(){
            $model = new NeighbourhoodCities;
            
            $hood_id = $_REQUEST['hood_id'];
            
           $cities = $model->retrieveAllCitiesInThisHood($hood_id);
           
           $target = [];
           
           foreach($cities as $cityid){
              $criteria = new CDbCriteria();
              $criteria->select = '*';
              $criteria->condition='id=:id';
              $criteria->params = array(':id'=>$cityid);
              $city= City::model()->find($criteria);
              
              $target[] = $city;
           }
            header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "city" => $target)
                           );
           
        }
        
        
        
         /**
         * This is the function that sets the intra city delivery rate of a city
         */
        public function actionsetintracitydeliveryrates(){
            
            //get the country id
            $state= $_REQUEST['state_id'];
         
            $_id = $_REQUEST['id'];
            
            $model=City::model()->findByPk($_id);
            $model->name = $_REQUEST['name'];
            $model->state_id = $state;
            //setting the standard shipping rates
            $model->intra_city_base_rate = $_REQUEST['intra_city_base_rate'];
            $model->intra_city_maximum_base_weight = $_REQUEST['intra_city_maximum_base_weight'];
            $model->intra_city_per_additional_kg = $_REQUEST['intra_city_per_additional_kg'];
            //setting the priority shipping rates
             $model->intra_city_base_rate_priority = $_REQUEST['intra_city_base_rate_priority'];
            $model->intra_city_maximum_base_weight_priority = $_REQUEST['intra_city_maximum_base_weight_priority'];
            $model->intra_city_per_additional_kg_priority = $_REQUEST['intra_city_per_additional_kg_priority'];
            //setting the same day  shipping rates
             $model->intra_city_base_rate_sameday = $_REQUEST['intra_city_base_rate_sameday'];
            $model->intra_city_maximum_base_weight_sameday = $_REQUEST['intra_city_maximum_base_weight_sameday'];
            $model->intra_city_per_additional_kg_sameday = $_REQUEST['intra_city_per_additional_kg_sameday'];
            $model->update_time = new CDbExpression('NOW()');
            //$model->update_user_id = Yii::app()->user->id;
            if($model->save()){
                       // $data['success'] = 'true';
                        $msg = 'The intra city delivery rate for this city is successfully set or modified';
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg)
                           );
                }else {
                   // $data['success'] = 'false';
                    $msg = 'Attempt to set or modify the intra city delivery rate for this city failed';
                     header('Content-Type: application/json');
                     echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                           );
                }
        }
        
        
        
        /**
         * This is the function that list all cities with packages for delivery for a courier 
         */
        public function actionlistallCitiesWithPackagesForDeliveryForThisCourier(){
            
            $model = new User;
            
            $user_id = Yii::app()->user->id;
            
            //get the contractor id of this user
            $contractor_id = $model->getTheContractorIdOfThisUser($user_id);
            
            //get all items assigned to this courier
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='courier_id=:courid';
            $criteria->params = array(':courid'=>$contractor_id);
            $orders= OrderItem::model()->findAll($criteria);
            
            $target = [];
            
            $cities = [];
            
            foreach($orders as $order){
                if($this->isThisOrderOpen($order['order_id'])){
                    $cities[] = $this->getTheCityOfDeliveryOfThisOrder($order['order_id']);
                }
            }
            
            $cities = array_unique($cities);
            
            //retrieve all the cities with packages for delivery
            foreach($cities as $city_id){
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:id';
                $criteria->params = array(':id'=>$city_id);
                $city= City::model()->find($criteria);
                
                $target[] = $city;
            }
            
            
             header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "city" => $target)
                           );
           
            
        }
        
        
        /**
         * This is the function that confirms if an order is open
         */
        public function isThisOrderOpen($order_id){
            $model = new Order;
            return $model->isThisOrderOpen($order_id);
        }
        
        
         /**
         * This is the function that retrieves the city of delivery of an order
         */
        public function getTheCityOfDeliveryOfThisOrder($order_id){
            $model = new Order;
            return $model->getTheCityOfDeliveryOfThisOrder($order_id);
        }
}
