<?php

class CityWhitelistController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update','addcitytowhitelist','removecityfromwhitelist'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	/**
         * This is the function that add a city to the whitelist
         */
        public function actionaddcitytowhitelist(){
            $model = new CityWhitelist;
            
            $model->city_id = $_REQUEST['city_id'];
            $city_name = $_REQUEST['city_name'];
            
            if($model->isThisCityInTheWhitelist($model->city_id)==false){
                if($model->save()){
                $msg = "'$city_name' city is successfully added to the whitelist";
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                        "msg" => $msg)
                           );
            }else{
                $msg = 'Attempt to add this city to the whitelist was unsuccessful';
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                        "msg" => $msg)
                           );
            }
                
                
            }else{
                $msg = 'This city is already in the whitelist and cannot be added again';
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                        "msg" => $msg)
                           );
                
            }
            
            
        }
        
        
        /**
         * This is the function that removes a city from the whitelist
         */
        public function actionremovecityfromwhitelist(){
            $model = new CityWhitelist;
            $city_id = $_REQUEST['city_id'];
            $city_name = $_REQUEST['city_name'];
            
           if($model->isThisCityInTheWhitelist($city_id)){
                if($model->isTheRemovalOfThisCityFromTheWhitelistASuccess($city_id)){
                    $msg = "'$city_name' city is successfully removed from the whitelist";
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                        "msg" => $msg)
                           );
                }else{
                    $msg = 'Attempt to remove this city from the whitelist was unsuccessful';
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                        "msg" => $msg)
                           );
                }
           }else{
                $msg = 'This city is not found in the whitelist and therefore the request is ignored';
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                        "msg" => $msg)
                           );
           }
        }
}
