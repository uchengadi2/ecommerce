<?php

class CartItemController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update','addthisproducttocart','listallproductsinacart','modifythiscartitemparameters',
                                    'removeitemfromcart'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	/**
         * This is the function that add a product to a cart
         */
        public function actionaddthisproducttocart(){
            $model = new CartItem;
            
            $user_id = Yii::app()->user->id;
            $quantity = $_REQUEST['quantity'];
            
            $model->cart_id = $this->getACartForThisUser($user_id);
            $model->product_id = $_REQUEST['product_id'];
            $model->pricing_id = $_REQUEST['pricing_id'];
            $model->promotion_type = $_REQUEST['promotion_type'];
            $model->promotion_id = $_REQUEST['promotion_id'];
            $model->inventory_id = $_REQUEST['inventory_id'];
            $model->quantity = $quantity;
            $model->date_added = new CDbExpression('NOW()');
            
            if($model->save()){
                 $msg = "This product is successfully added to cart";
                                 header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                 "success" => mysql_errno() == 0,
                                  "msg" => $msg)
                            );
            }else{
                $msg = "The attempt to add this product to cart failed. Please try again or contact customer service for assistance";
                                 header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                 "success" => mysql_errno() != 0,
                                  "msg" => $msg,
                                 )
                            );
            }
                    
            
        }
        
        
        /**
         * This is the function that retrieves a cart for a user
         */
        public function getACartForThisUser($user_id){
            $model = new Cart;
            return $model->getACartForThisUser($user_id);
        }
        
        
        /**
         * This is the function that retrieves all items in a cart
         */
        public function actionlistallproductsinacart(){
            
            $model = new Cart;
            
            $user_id = Yii::app()->user->id;
            
            $cart_id = $model->getTheOpenCartIdOfThisUser($user_id);
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='cart_id=:cartid';
            $criteria->params = array(':cartid'=>$cart_id);
            $cartitems= CartItem::model()->findAll($criteria);
            $data = [];
            foreach($cartitems as $item){
                $product_id = $item['product_id'];
                $pricing_id = $item['pricing_id'];
                $promotion_id = $item['promotion_id'];
                $inventory_id = $item['inventory_id'];
                $quantity = $item['quantity'];
                $item_id = $item['id'];
                
                 $q ="select d.id as promotion_id,c.id as pricing_id, c.price_per_unit as 'price', c.prime_customer_discount_rate,c.inventory_id,c.minimum_order_quantity,
                    a.id as product_id, a.icon, a.name, a.merchant_id, a.description, a.classification,
                    d.id as promotion_id,d.available_cities, d.type as promotion_type, d.pricing_id,d.condition, d.x_quantity, d.y_quantity, d.y_product, d.y_product_quantity,d.y_percentage,d.start_date,d.end_date,
                    (select id from cart_item where id=$item_id) as id,
                    (select symbol from measurement_type where id=(select measurement_type_id from pricing where id=$pricing_id)) as unit, c.measurement_type_id as measurement_type_id,
                    (select quantity from cart_item where id= $item_id) as quantity, 
                    (select id from cart_item where id= $item_id) as cart_item_id,  
                    (select cart_id from cart_item where id= $item_id) as cart_id,      
                    (select count(*) from promotion where end_date >= NOW() and id=$promotion_id) as is_pricing_on_promotion from product a
                    JOIN inventory b ON a.id=b.product_id
                    JOIN pricing c ON b.id=c.inventory_id
                    JOIN promotion d ON c.id=d.pricing_id 
                    where c.id =$pricing_id and d.id=$promotion_id and a.id=$product_id and b.id=$inventory_id";
                   
             
             $cmd = Yii::app()->db->createCommand($q);
             $result = $cmd->query();
             
             foreach($result as $res){
                 $data[] = $res;
             }
            }
            
           
             
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "item"=>$data,
                                    
                    
                            ));
                
                
            }
            
            
            /**
             * This is the function that modifies a cart item quantity
             */
            public function actionmodifythiscartitemparameters(){
               $id = $_REQUEST['cart_item_id'];
                $model=  CartItem::model()->findByPk($id);
                 $model->quantity = $_REQUEST['product_quantity'];
                $model->date_updated = new CDbExpression('NOW()');
            
            if($model->save()){
                 $msg = "This cart item is successfully updated";
                                 header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                 "success" => mysql_errno() == 0,
                                  "msg" => $msg)
                            );
            }else{
                $msg = "The attempt to update this cart item failed. Please try again or contact customer service for assistance";
                                 header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                 "success" => mysql_errno() != 0,
                                  "msg" => $msg,
                                 )
                            );
            }
                
            }
            
            
            /**
             * This is the function that will remove an item from a cart
             */
            public function actionremoveitemfromcart(){
                
                $id = $_POST['id'];
             $model= CartItem::model()->findByPk($id);
            
            if($model === null){
                $data['success'] = 'undefined';
                $data['msg'] = 'No such record exist';
                header('Content-Type: application/json');
                echo CJSON::encode($data);
                                      
            }else if($model->delete()){
                    $data['success'] = 'true';
                    $data['msg'] = "This item was successfully removed from the cart";
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
            } else {
                    $data['success'] = 'false';
                    $data['msg'] = 'removal of item from the cart was unsuccessful';
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
                            
                }
                
           
            }
        
}
