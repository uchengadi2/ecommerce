<?php

class PackagingController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update','listAllItemsInAPackage','additemtopackage','removeitemfrompackage'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	/**
         * This is the function that retrieves all items in a package
         */
        public function actionlistAllItemsInAPackage(){
            $model = new Packaging;
            
            $package_id = $_REQUEST['package_id'];
            
            $target = [];
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='package_id=:packid';
            $criteria->params = array(':packid'=>$package_id);
            $items= Packaging::model()->findAll($criteria);
            
            foreach($items as $item){
                $criteria = new CDbCriteria();
                $criteria->select = '*';
                $criteria->condition='id=:orderid';
                $criteria->params = array(':orderid'=>$item['order_item_id']);
                $order= OrderItem::model()->find($criteria);
                $target[] = $order;
                
            }
            
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    //"order" => $items,
                                    "item"=>$target,
                                   
                            ));
        }
        
        
        /**
         * This is the function that adds item to a package
         */
        public function actionadditemtopackage(){
            $model = new Packaging;
            $model->package_id = $_REQUEST['package_id'];
             $model->order_item_id = $_REQUEST['item_id'];
             $model->date_packaged = new CDbExpression('NOW()');
             $model->packaged_by = Yii::app()->user->id;
             
             if($this->isThisPackageOpen($model->package_id)){
                 if($model->isThisItemAlreadyInThePackage($model->package_id,$model->order_item_id) == false){
                 if($model->save()){
                 $msg = "This item is successfully added to the package";
                                 header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                 "success" => mysqli_connect_errno() == 0,
                                  "msg" => $msg)
                            );
                 
             }else{
                  $msg = 'Validaion Error: Attempt to add this item to this package failed. Please try again';
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                               );
             }
                 
             }else{
                 $msg = 'This item is already in this package, therefore the request is ignored';
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                               );
                 
             }
                 
             }else{
                  $msg = 'You are trying to add an item to a package that is already closed. You either reopen the package or create a new one';
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                               );
                 
             }
             
             
             
             
        }
        
        
        
        /**
         * This is the function that deletes an item from a package
         */
        public function actionremoveitemfrompackage(){
            
            $package_id = $_POST['package_id'];
            $item_id = $_POST['item_id'];
            
            //get the packaging id
            $packaging_id = $this->getThePackagingId($package_id,$item_id);
            
            $model=  Packaging::model()->findByPk($packaging_id);
            
            if($this->isThisPackageOpen($package_id)){
                if($model->delete()){
                $msg = "This item is successdully removed from this package";
                                 header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                 "success" => mysqli_connect_errno() == 0,
                                  "msg" => $msg)
                            );
            }else{
                 $msg = 'Error: Attempt to remove this item from the package failed. Please try again';
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                               );
            }
                
            }else{
                 $msg = 'You cannot remove an item from a package that is already closed. To do that you need to reopen the package and try again.';
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                               );
                
            }
                
            
            
            
            
            
        }
        
        
        /**
         * This is the function that retrieves a packaging is
         */
        public function getThePackagingId($package_id,$item_id){
            $model = new Packaging;
            return $model->getThePackagingId($package_id,$item_id);
        }
        
        
        /**
         * This is the function that will confirm if a package is open
         */
        public function isThisPackageOpen($package_id){
            $model = new Package;
            return $model->isThisPackageOpen($package_id);
        }
}
