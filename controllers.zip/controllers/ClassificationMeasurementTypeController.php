<?php

class ClassificationMeasurementTypeController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update','removemeasrementtypetoclassification','addmeasrementtypetoclassification'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	/**
         * This is the function that add a measurement type to a classification
         */
        public function actionaddmeasrementtypetoclassification(){
            $model = new ClassificationMeasurementType;
            
            $model->classification = $_REQUEST['classification'];
            $model->measurement_type_id = $_REQUEST['measurement_type_id'];
                       
            if($model->measurement_type_id !=""){
                if($model->isThisMeasurementTypeAlreadyAssignedToThisClassification($model->classification,$model->measurement_type_id)==false){
                if($model->save()){
                $msg = "New measurement type is successfully added to the '$model->classification' product classification";
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg)
                           );
            }else{
                $msg = "Attempt to add this measurement type to the '$model->classification' classification was unsuccessful";
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg)
                           );
            }
                
                
            }else{
                $msg = 'This measurement type is already assigned to this classification and cannot be added again';
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg)
                           );
                
            }
                
                
                
            }else{
                $msg = 'Please select a measurement type to add';
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg)
                           );
                
            }
            
            
            
            
        }
        
        
        /**
         * This is the function that removes a measurement type from a classification
         */
        public function actionremovemeasrementtypetoclassification(){
            $model = new ClassificationMeasurementType;
            $classification = $_REQUEST['classification'];
            $measurement_type_id = $_REQUEST['measurement_type_id'];
                        
            if($measurement_type_id !=""){
                if($model->isThisMeasurementTypeAlreadyAssignedToThisClassification($classification,$measurement_type_id)){
                if($model->isTheRemovalOfThisMeasurementTypeFromClassificationASuccess($classification,$measurement_type_id)){
                    $msg = "The measurement type is successfully removed from the '$classification' classification";
                          header('Content-Type: application/json');
                          echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg)
                           );
                }else{
                    $msg = 'Attempt to remove this meassurement type from the classification was unsuccessful';
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg)
                           );
                }
           }else{
                $msg = 'This measurement type is not assigned to this classification and therefore the request is ignored';
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg)
                           );
           }
            }else{
                 $msg = 'Please select a measurement type to remove';
                         header('Content-Type: application/json');
                        echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                        "msg" => $msg)
                           );
            }
            
           
        }
}
