<?php

class OrderController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view','placeorder'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update','listAllOpenOrders','listAllMerchantOpenOrders','listAllOrders','retrievesomeitemsdetails',
                                    'listAllOpenOrders','listAllOpenOrdersWithConfirmedPayment'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	/**
	 * Displays a particular model.
	 * @param integer $id the ID of the model to be displayed
	 */
	public function actionView($id)
	{
		$this->render('view',array(
			'model'=>$this->loadModel($id),
		));
	}

	/**
         * This is the function that list all open orders
         */
        public function actionlistAllOpenOrders(){
            
             $criteria = new CDbCriteria();
              $criteria->select = '*';
              $criteria->condition='status=:status';
              $criteria->params = array(':status'=>"open");
              $orders= Order::model()->findAll($criteria);
              
              header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "order" => $orders,
                                   
                    
                            ));
              
        }
        
        
        /**
         * This is the function that retrieves all merchant items in open oeders
         */
        public function actionlistAllMerchantOpenOrders(){
            $model = new User;
            $user_id = Yii::app()->user->id;
            
            $merchant_id = $model->getTheMerchantIdOfThisUser($user_id);
            
                        
            //retrieve all the open orders
                   
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='status=:status';
            $criteria->params = array(':status'=>"open");
            $orders= Order::model()->findAll($criteria);
            
            
            
             
           $target = [];
           foreach($orders as $order){
              if($this->isThisOrderWithMerchantProduct($order['id'],$merchant_id)){
                   $target[] = $order;
               }
              
          }
           
           
           
           
           
           header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    //"order" => $items,
                                    "order"=>$target,
                                   
                            ));
            
            
        }
        
        
        /**
         * This is the function that confirms if an order containes a merchant's product
         */
        public function isThisOrderWithMerchantProduct($order_id,$merchant_id){
            $model = new OrderItem;
            return $model->isThisOrderWithMerchantProduct($order_id,$merchant_id);
        }
        
        
        /**
         * this is the function that list all orders
         */
        public function actionlistAllOrders(){
             $order = Order::model()->findAll();
               header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "order" => $order,
                                   
                    
                            ));
        }
        
        
        /**
         * This is the function that retrieves some details about an order item
         */
        public function actionretrievesomeitemsdetails(){
            
            $product_id = $_REQUEST['product_id'];
            $order_id = $_REQUEST['order_id'];
            $pricing_id = $_REQUEST['pricing_id'];
            $promotion_id = $_REQUEST['promotion_id'];
                    
            
            //get the product details
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$product_id);
            $product= Product::model()->find($criteria);
            
            //get the order details
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$order_id);
            $order= Order::model()->find($criteria);
            
             //get the city of delivery details
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$order['delivery_city_id']);
            $city= City::model()->find($criteria);
            
            
             //get the stateof delivery details
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$city['state_id']);
            $state= State::model()->find($criteria);
            
            //get the unit pricing details
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$pricing_id);
            $pricing= Pricing::model()->find($criteria);
            
            //get the pricing details
              //get the unit measurement type details
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$pricing['measurement_type_id']);
            $unit= MeasurementType::model()->find($criteria);
            
               //get the product pricing promotion details
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$promotion_id);
            $promotion= Promotion::model()->find($criteria);
            
            
            header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "order" => $order,
                                   "product"=>$product,
                                    "unit"=>$unit,
                                    "pricing"=>$pricing,
                                    "promotion"=>$promotion,
                                    "city"=>$city,
                                    "state"=>$state
                    
                            ));
            
        }
        
        
        
        /**
         * This is the function that list all open orders with confirmed payment
         */
        public function actionlistAllOpenOrdersWithConfirmedPayment(){
            $model = new Payment;
             $criteria = new CDbCriteria();
              $criteria->select = '*';
              $criteria->condition='status=:status';
              $criteria->params = array(':status'=>"open");
              $orders= Order::model()->findAll($criteria);
              
              $target = [];
              
              foreach($orders as $order){
                  if($model->isThePaymentOfThisOrderConfirmed($order['id'])){
                      $target[] = $order;
                  }
              }
              
              header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysql_errno() == 0,
                                    "order" => $target,
                                   
                    
                            ));
              
        }
        
        
        /**
         * This is the function that places an order fou anonynous buy now customer 
         */
        public function actionplaceorder(){
            $model = new Order;
            
                $delivery_cost = $_REQUEST['delivery_cost'];
                $total_cost_deposit = $_REQUEST['total_cost_deposit'];
                $model->status = "open";
                $model->delivery_address = $_REQUEST['delivery_address'];
                $model->delivery_city_id = $_REQUEST['delivery_city_id'];
                $model->receiver_mobile_number = $_REQUEST['receiver_mobile_number'];
                $model->address_landmark = $_REQUEST['address_landmark'];
                $model->nearest_bus_stop = $_REQUEST['nearest_bus_stop'];
                $model->person_in_care_of = $_REQUEST['person_in_care_of'];
                $model->delivery_preference = $_REQUEST['delivery_preference'];
                $model->other_relevent_information = $_REQUEST['other_relevent_information'];
                $model->date_ordered = new CDbExpression('NOW()');
                $model->ordered_by = $_REQUEST['user_id'];
                $model->email = $_REQUEST['email'];
                $model->mobile_number = $_REQUEST['mobile_number'];
                
                $model->order_number = $model->generateThisOrderUniqueNumber($_REQUEST['product_id'],$_REQUEST['warehouse_location_id'],$model->delivery_city_id);
                $error_counter = 0;
                
                
                
                   if($_REQUEST['is_a_prime_member']==1){
                       if($this->isThisUserAPrimeMember($_REQUEST['prime_member_number'])){
                           $model->is_a_prime_member = $_REQUEST['is_a_prime_member'];
                            $model->prime_member_number = $_REQUEST['prime_member_number'];
                            $total_price_of_items= $_REQUEST['prime_members_total_price_post_promotion_and_delivery'];
                            $is_a_prime_member=1;
                       }else{
                           $error_counter = $error_counter + 1;
                           $is_a_prime_member=0;
                           $total_price_of_items= $_REQUEST['total_price_post_promotion_and_delivery'];
                           $model->prime_member_number ="";
                       }
                       
                   }else{
                        $model->is_a_prime_member = 0;
                        $model->prime_member_number = " ";
                        $total_price_of_items= $_REQUEST['total_price_post_promotion_and_delivery'];
                        $is_a_prime_member=0;
                   }
                   
                 if($_REQUEST['payment_mode'] == "on_deposit_using_online"){
                       $total_cost_deposit = round($total_cost_deposit,2);
                       $total_price_of_items = round($total_price_of_items,2);
                       
                   }else if($_REQUEST['payment_mode'] == "on_deposit_using_bank_transfer"){
                       $total_cost_deposit = round($total_cost_deposit,2);
                       $total_price_of_items = round($total_price_of_items,2);
                   }else{
                       $total_cost_deposit=round($total_price_of_items,2);
                       $total_price_of_items=round($total_price_of_items,2);
                   }
                
                
                   
                   if($error_counter == 0){
                       if($model->save()){
                    if($this->isOrderItemDetailsCorrectlyCreated($model->id,$_REQUEST['product_id'],$_REQUEST['quantity'],$_REQUEST['measurement_type_id'],$_REQUEST['promotion_id'],$_REQUEST['pricing_id'],$model->ordered_by)){
                        $invoice_number = $this->makePaymentAndGenerateTheInvoiceNumber($model->id,$model->order_number,$_REQUEST['payment_mode'],$delivery_cost,$total_cost_deposit,$total_price_of_items,$model->ordered_by,$_REQUEST['product_id'],$_REQUEST['warehouse_location_id'],$model->delivery_city_id);
                             if($_REQUEST['payment_mode'] == "on_deposit_using_online"){
                                  header('Content-Type: application/json');
                                    echo CJSON::encode(array(
                                        "success" => mysql_errno() == 0,
                                        "invoice_number" => $invoice_number,
                                        "order_number"=>$model->order_number,
                                        "is_a_prime_member"=>$is_a_prime_member,
                                        "amount"=>round($total_cost_deposit,2),
                                        "email"=>$model->email,
                                        "membership_number"=>$model->prime_member_number
                                    ));
                                 
                             }else if($_REQUEST['payment_mode'] == "on_deposit_using_bank_transfer"){
                                 $msg = "Your order number is '$model->order_number' and the invoice number is '$invoice_number'. Please effect transfer using the order number attribute for easy verification";
                                 header('Content-Type: application/json');
                                    echo CJSON::encode(array(
                                        "success" => mysql_errno() == 0,
                                        "msg" =>$msg,
                                         "invoice_number" => $invoice_number,
                                        "order_number"=>$model->order_number,
                                        "is_a_prime_member"=>$is_a_prime_member
                                    ));
                                 
                             }else if($_REQUEST['payment_mode'] == "online"){
                                 header('Content-Type: application/json');
                                    echo CJSON::encode(array(
                                        "success" => mysql_errno() == 0,
                                        "invoice_number" => $invoice_number,
                                        "order_number"=>$model->order_number,
                                        "is_a_prime_member"=>$is_a_prime_member=0,
                                        "amount"=>round($total_price_of_items,2),
                                        "email"=>$model->email,
                                        "membership_number"=>$model->prime_member_number
                                    ));
                                 
                             }else if($_REQUEST['payment_mode'] == "on_delivery"){
                                 $msg = "Your order number is '$model->order_number' and the invoice number is '$invoice_number'. On delivery you will have to pay the total sum of '=N=$total_price_of_items' before taking ownership of the product ";
                                 header('Content-Type: application/json');
                                    echo CJSON::encode(array(
                                        "success" => mysql_errno() == 0,
                                        "msg" => $msg,
                                        
                                    ));
                                 
                             }else if($_REQUEST['payment_mode'] == "bank_transfer"){
                                 $msg = "Effect the bank transfer using this order number: '$model->order_number' in the transfer instruction. However, the invoice number of this transaction is '$invoice_number'";
                                  header('Content-Type: application/json');
                                    echo CJSON::encode(array(
                                        "success" => mysql_errno() == 0,
                                        "msg" => $msg,
                                         "invoice_number" => $invoice_number,
                                        "order_number"=>$model->order_number
                                        
                                    ));
                             }else if($_REQUEST['payment_mode'] == "on_credit"){
                                 $msg = "Validaion Error: Check your file fields for correctness";
                                 header('Content-Type: application/json');
                                    echo CJSON::encode(array(
                                        "success" => mysql_errno() == 0,
                                        "msg" => $msg,
                                         "invoice_number" => $invoice_number,
                                        "order_number"=>$model->order_number
                                        
                                    ));
                             }
                                
                   
                    }
                }else{
                    $msg = 'Attempt to place this order was not successful. Please try again or contact customer service';
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                               );
                
                
                }
                       
                   }else{
                        $msg = 'Your Prime Membership number could not be verified. Kindly check the number and try again';
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysql_errno() != 0,
                                        "msg" => $msg)
                               );
                       
                   }
            
            
                
          
            
            
        }
        
        
        /**
         * This is the function that adds an item to an order
         */
        public function isOrderItemDetailsCorrectlyCreated($order_id,$product_id,$quantity,$measurement_type_id,$promotion_id,$pricing_id,$ordered_by){
            $model = new OrderItem;
            return $model->isOrderItemDetailsCorrectlyCreated($order_id,$product_id,$quantity,$measurement_type_id,$promotion_id,$pricing_id,$ordered_by);
            
        }
        
        /**
         * This is the function that effects an order payment
         */
        public function makePaymentAndGenerateTheInvoiceNumber($order_id,$order_number,$payment_mode,$delivery_cost,$total_cost_deposit,$total_price_of_items,$ordered_by,$product_id,$warehouse_location_id,$delivery_city_id){
            $model = new Payment;
            return $model->makePaymentAndGenerateTheInvoiceNumber($order_id,$order_number,$payment_mode,$delivery_cost,$total_cost_deposit,$total_price_of_items,$ordered_by,$product_id,$warehouse_location_id,$delivery_city_id);
            
        }
        
        
        /**
         * This is the function that determines if a user is a ptime meber
         */
        public function isThisUserAPrimeMember($prime_member_number){
            $model = new Membership;
            return $model->isThisUserAPrimeMember($prime_member_number);
        }
        
        
}
