# ext-theme-neptune-17e38dad-3d1a-4064-8300-b4e3756be949/resources

This folder contains static resources (typically an `"images"` folder as well).
