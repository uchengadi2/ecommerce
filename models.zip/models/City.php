<?php

/**
 * This is the model class for table "city".
 *
 * The followings are the available columns in table 'city':
 * @property string $id
 * @property string $name
 * @property string $description
 * @property string $state_id
 * @property string $zip_code
 * @property string $create_time
 * @property integer $create_user_id
 * @property string $update_time
 * @property integer $update_user_id
 *
 * The followings are the available model relations:
 * @property State $state
 * @property Contractor[] $contractors
 * @property Warehouse[] $warehouses
 */
class City extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'city';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('name, state_id', 'required'),
			array('create_user_id, update_user_id', 'numerical', 'integerOnly'=>true),
			array('name', 'length', 'max'=>250),
			array('state_id, zip_code', 'length', 'max'=>10),
			array('description, create_time, update_time', 'safe'),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('id, name, description, state_id, zip_code, create_time, create_user_id, update_time, update_user_id', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
			'state' => array(self::BELONGS_TO, 'State', 'state_id'),
			'contractors' => array(self::MANY_MANY, 'Contractor', 'contractor_catchment(city_id, contractor_id)'),
			'warehouses' => array(self::HAS_MANY, 'Warehouse', 'city_id'),
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'name' => 'Name',
			'description' => 'Description',
			'state_id' => 'State',
			'zip_code' => 'Zip Code',
			'create_time' => 'Create Time',
			'create_user_id' => 'Create User',
			'update_time' => 'Update Time',
			'update_user_id' => 'Update User',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('id',$this->id,true);
		$criteria->compare('name',$this->name,true);
		$criteria->compare('description',$this->description,true);
		$criteria->compare('state_id',$this->state_id,true);
		$criteria->compare('zip_code',$this->zip_code,true);
		$criteria->compare('create_time',$this->create_time,true);
		$criteria->compare('create_user_id',$this->create_user_id);
		$criteria->compare('update_time',$this->update_time,true);
		$criteria->compare('update_user_id',$this->update_user_id);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return City the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
        
        
        /**
         * This is the function that gets the city name given its id
         */
        public function getTheNameOfThisCity($id){
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$id);
            $city = City::model()->find($criteria); 
            
            return $city['name'];
            
        }
        
        /**
         * This is the function that retrieves the standard intra city delivery rate
         */
        public function getTheStandardIntraCityRateOfThisCity($id,$total_weight_for_delivery){
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$id);
            $city = City::model()->find($criteria); 
            
            if($city['intra_city_maximum_base_weight']>=$total_weight_for_delivery){
                return $city['intra_city_base_rate'];
            }else{
                $weight_diff = (double)$total_weight_for_delivery - (double)$city['intra_city_maximum_base_weight'];
                $rate = $city['intra_city_base_rate'] + ($weight_diff * (double)$city['intra_city_per_additional_kg']);
                return $rate;
            }
        }
        
        
        /**
         * This is the function that retrieves the priority intra city delivery rate
         */
        public function getThePriorityIntraCityRateOfThisCity($id,$total_weight_for_delivery){
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$id);
            $city = City::model()->find($criteria); 
            
            if($city['intra_city_maximum_base_weight_priority']>=$total_weight_for_delivery){
                return $city['intra_city_base_rate_priority'];
            }else{
                $weight_diff = (double)$total_weight_for_delivery - (double)$city['intra_city_maximum_base_weight_priority'];
                $rate = $city['intra_city_base_rate_priority'] + ($weight_diff * (double)$city['intra_city_per_additional_kg_priority']);
                return $rate;
            }
        }
        
        
        /**
         * This is the function that retrieves the sameday intra city delivery rate
         */
        public function getTheSamedayIntraCityRateOfThisCity($id,$total_weight_for_delivery){
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='id=:id';
            $criteria->params = array(':id'=>$id);
            $city = City::model()->find($criteria); 
            
            if($city['intra_city_maximum_base_weight_sameday']>=$total_weight_for_delivery){
                return $city['intra_city_base_rate_sameday'];
            }else{
                $weight_diff = (double)$total_weight_for_delivery - (double)$city['intra_city_maximum_base_weight_sameday'];
                $rate = $city['intra_city_base_rate_sameday'] + ($weight_diff * (double)$city['intra_city_per_additional_kg_sameday']);
                return $rate;
            }
        }
       
}
