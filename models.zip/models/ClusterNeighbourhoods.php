<?php

/**
 * This is the model class for table "cluster_neighbourhoods".
 *
 * The followings are the available columns in table 'cluster_neighbourhoods':
 * @property string $id
 * @property string $neighbourhood_id
 * @property string $cluster_id
 * @property string $create_time
 * @property integer $create_user_id
 * @property string $update_time
 * @property integer $update_user_id
 */
class ClusterNeighbourhoods extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'cluster_neighbourhoods';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('neighbourhood_id, cluster_id', 'required'),
			array('create_user_id, update_user_id', 'numerical', 'integerOnly'=>true),
			array('neighbourhood_id, cluster_id', 'length', 'max'=>10),
			array('create_time, update_time', 'safe'),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('id, neighbourhood_id, cluster_id, create_time, create_user_id, update_time, update_user_id', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'neighbourhood_id' => 'Neighbourhood',
			'cluster_id' => 'Cluster',
			'create_time' => 'Create Time',
			'create_user_id' => 'Create User',
			'update_time' => 'Update Time',
			'update_user_id' => 'Update User',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('id',$this->id,true);
		$criteria->compare('neighbourhood_id',$this->neighbourhood_id,true);
		$criteria->compare('cluster_id',$this->cluster_id,true);
		$criteria->compare('create_time',$this->create_time,true);
		$criteria->compare('create_user_id',$this->create_user_id);
		$criteria->compare('update_time',$this->update_time,true);
		$criteria->compare('update_user_id',$this->update_user_id);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return ClusterNeighbourhoods the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
        
        
        /**
         * This is the function that retrieves the cities in a neighbourhood
         */
        public function retrieveAllNieghbourhoodsInThisHood($cluster_id){
            $target = [];
            
             $criteria = new CDbCriteria();
              $criteria->select = '*';
              $criteria->condition='cluster_id=:clusid';
              $criteria->params = array(':clusid'=>$cluster_id);
              $hoods= ClusterNeighbourhoods::model()->findAll($criteria);
              
              foreach($hoods as $hood){
                  $target[] = $hood['neighbourhood_id'];
              }
              
              return $target;
        }
        
        
        /**
         * This is the function that retrieves a grouping id
         */
        public function getTheGroupingIdOfThisClusterAssignment($cluster_id,$neighbourhood_id){
            $model = new ClusterNeighbourhoods;
            $criteria = new CDbCriteria();
              $criteria->select = '*';
              $criteria->condition='cluster_id=:clusterid and neighbourhood_id=:hoodid';
              $criteria->params = array(':clusterid'=>$cluster_id,':hoodid'=>$neighbourhood_id);
              $grouping= ClusterNeighbourhoods::model()->find($criteria);
              
              return $grouping['id'];
        }
        
        /**
         * This is the function that confirms if a neighbourhood is already assigned to a cluster
         */
        public function isThisNeighbourhoodAlreadyAssignedToACluster($neighbourhood_id){
            $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('cluster_neighbourhoods')
                    ->where("neighbourhood_id=$neighbourhood_id");
                $result = $cmd->queryScalar();
                
                if($result>0){
                    return true;
                }else{
                    return false;
                }
        }
        
        
         /**
         * This is the function that confirms if a neighbourhood is already assigned to a cluster
         */
        public function isThisNeighbourhoodAlreadyAssignedToThisCluster($cluster_id,$neighbourhood_id){
            $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('cluster_neighbourhoods')
                    ->where("neighbourhood_id=$neighbourhood_id and cluster_id=$cluster_id");
                $result = $cmd->queryScalar();
                
                if($result>0){
                    return true;
                }else{
                    return false;
                }
        }
        
        
        /**
         * This is the function that determines if a city neighbourhood is a cluster
         */
        public function isThisCityNeighbourhoodAlreadyAssignedToACluster($city_id){
            $model = new NeighbourhoodCities;
            if($model->isThisCityAlreadyAssignedToANeighbourhood($city_id)){
                $hood_id = $model->getTheNeighbourhoodIdOfThisCity($city_id);
                if($this->isThisNeighbourhoodAlreadyAssignedToACluster($hood_id)){
                    return true;
                }else{
                    return false;
                }
            }else{
                return false;
                
            }
        }
        
        
        
        /**
         * This is the function that gets th cluster id of a city's neighbourhood
         */
        public function getTheClusterIdOfThisCityNeighbourhood($city_id){
            $model = new NeighbourhoodCities;
            $hood_id = $model->getTheNeighbourhoodIdOfThisCity($city_id);
            $cluster_id = $this->getTheClusterIdOfThisNeighbourhood($hood_id);
            return $cluster_id;
        }
        
        
         /**
         * This is the function that retrieves the  id of a cluster
         */
        public function getTheClusterIdOfThisNeighbourhood($hood_id){
            $criteria = new CDbCriteria();
              $criteria->select = '*';
              $criteria->condition='neighbourhood_id=:hoodid';
              $criteria->params = array(':hoodid'=>$hood_id);
              $cluster= ClusterNeighbourhoods::model()->find($criteria);
              
              return $cluster['cluster_id'];
        }
}
