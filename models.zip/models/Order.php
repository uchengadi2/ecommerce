<?php

/**
 * This is the model class for table "order".
 *
 * The followings are the available columns in table 'order':
 * @property string $id
 * @property string $order_number
 * @property string $status
 * @property string $confirmation_status
 * @property integer $is_term_acceptable
 * @property string $delivery_address
 * @property integer $delivery_city_id
 * @property string $receiver_mobile_number
 * @property string $address_landmark
 * @property string $nearest_bus_stop
 * @property string $person_in_care_of
 * @property string $payment_preference
 * @property string $date_ordered
 * @property string $last_updated_date
 * @property integer $ordered_by
 * @property integer $order_updated_by
 */
class Order extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'order';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('status', 'required'),
			array('is_term_acceptable, delivery_city_id, ordered_by, order_updated_by', 'numerical', 'integerOnly'=>true),
			array('order_number', 'length', 'max'=>50),
			array('status', 'length', 'max'=>6),
			array('confirmation_status', 'length', 'max'=>11),
			array('delivery_address, address_landmark, nearest_bus_stop, person_in_care_of', 'length', 'max'=>250),
			array('receiver_mobile_number', 'length', 'max'=>100),
			array('payment_preference', 'length', 'max'=>7),
			array('date_ordered, last_updated_date', 'safe'),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('id, order_number, status, confirmation_status, is_term_acceptable, delivery_address, delivery_city_id, receiver_mobile_number, address_landmark, nearest_bus_stop, person_in_care_of, payment_preference, date_ordered, last_updated_date, ordered_by, order_updated_by', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'order_number' => 'Order Number',
			'status' => 'Status',
			'confirmation_status' => 'Confirmation Status',
			'is_term_acceptable' => 'Is Term Acceptable',
			'delivery_address' => 'Delivery Address',
			'delivery_city_id' => 'Delivery City',
			'receiver_mobile_number' => 'Receiver Mobile Number',
			'address_landmark' => 'Address Landmark',
			'nearest_bus_stop' => 'Nearest Bus Stop',
			'person_in_care_of' => 'Person In Care Of',
			'payment_preference' => 'Payment Preference',
			'date_ordered' => 'Date Ordered',
			'last_updated_date' => 'Last Updated Date',
			'ordered_by' => 'Ordered By',
			'order_updated_by' => 'Order Updated By',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('id',$this->id,true);
		$criteria->compare('order_number',$this->order_number,true);
		$criteria->compare('status',$this->status,true);
		$criteria->compare('confirmation_status',$this->confirmation_status,true);
		$criteria->compare('is_term_acceptable',$this->is_term_acceptable);
		$criteria->compare('delivery_address',$this->delivery_address,true);
		$criteria->compare('delivery_city_id',$this->delivery_city_id);
		$criteria->compare('receiver_mobile_number',$this->receiver_mobile_number,true);
		$criteria->compare('address_landmark',$this->address_landmark,true);
		$criteria->compare('nearest_bus_stop',$this->nearest_bus_stop,true);
		$criteria->compare('person_in_care_of',$this->person_in_care_of,true);
		$criteria->compare('payment_preference',$this->payment_preference,true);
		$criteria->compare('date_ordered',$this->date_ordered,true);
		$criteria->compare('last_updated_date',$this->last_updated_date,true);
		$criteria->compare('ordered_by',$this->ordered_by);
		$criteria->compare('order_updated_by',$this->order_updated_by);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return Order the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
        
        /**
         * This is the function that confirms if an order is open
         */
        public function isThisOrderOpen($order_id){
            $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('order')
                    ->where("id = $order_id and status='open'");
                $result = $cmd->queryScalar();
                
                if($result>0){
                    return true;
                }else{
                    return false;
                }
        }
        
         /**
         * This is the functionn that will generate the orcer number for an order
         */
        public function generateThisOrderUniqueNumber($product_id,$warehouse_location_id,$delivery_city_id){
             //get the date of an order
                $order_date = date("dmY",$this->getTheDateOfThisOrder());
                
                 //generate a random number
                $random_number = $this->generateTheRandomNumber();
                
                 //get the order number
                $order_number = "$random_number$delivery_city_id$product_id$warehouse_location_id";
                
                return $order_number;
                
                
            
        }
        
        
          /**
            * This is the function that fetches the order date for order number construction
            */
            public function getTheDateOfThisOrder(){
                //get todays date
                $today = mktime(0, 0, 0, date("m")  , date("d"), date("Y"));
                
               return $today;
            }
            
            
             /**
             * This is the function that generates a random number
             */
            public function generateTheRandomNumber(){
                
                //get todays date
                $today = mktime(0, 0, 0, date("m")  , date("d"), date("Y"));
                //generate random numbe from 0 to $today
                $random_number = mt_rand(0,$today);
               return $random_number;
            }
            
            
             /**
             * This is the function that gets the order number first four letters
             */
            public function getTheFirstFourLettersOfTheOrderNumber($order_number){
                
                return substr($order_number,0,4);
            }
            
        
        
        /**
         * This is the function that retrieves the city of delivery of an order
         */
        public function getTheCityOfDeliveryOfThisOrder($order_id){
            $criteria = new CDbCriteria();
              $criteria->select = '*';
              $criteria->condition='id=:id';
              $criteria->params = array(':id'=>$order_id);
              $order= Order::model()->find($criteria);
              
              return $order['delivery_city_id'];
        }
        
        
        /**
         * This is the function that retrieves the delivery cost of an order
         */
        public function getTheDeliveryCostOfThisOrder($delivery_city_id,$measurement_type_id,$warehouse_location_id,$quantity,$delivery_preference){
            
           if($this->isDeliveryAndStoreLocationSameCity($delivery_city_id,$warehouse_location_id)){
                $delivery_cost = $this->getTheIntraCityDeliveryCostOfThisOrder($delivery_city_id,$measurement_type_id,$warehouse_location_id,$quantity,$delivery_preference);
               return $delivery_cost;
                
          }else if($this->isDeliveryAndStoreLocationInSameNeighbourhood($delivery_city_id,$warehouse_location_id)){
                 $delivery_cost = $this->getTheIntraNeighbourhoodDeliveryCostOfThisOrder($delivery_city_id,$measurement_type_id,$warehouse_location_id,$quantity,$delivery_preference);
                 return $delivery_cost;
                 
            }else if($this->isDeliveryAndStoreLocationInSameCluster($delivery_city_id,$warehouse_location_id)){
                $delivery_cost = $this->getTheIntraClusterDeliveryCostOfThisOrder($delivery_city_id,$measurement_type_id,$warehouse_location_id,$quantity,$delivery_preference);
                return $delivery_cost;
            }else if($this->isDeliveryAndStoreLocationOnSeparateCluster($delivery_city_id,$warehouse_location_id)){
                $delivery_cost = $this->getTheInterClusterDeliveryCostOfThisOrder($delivery_city_id,$measurement_type_id,$warehouse_location_id,$quantity,$delivery_preference);
                return $delivery_cost;
               
               
            }else{
                $delivery_cost = $this->getTheOrphanLocationDeliveryCostOfThisOrder($delivery_city_id,$measurement_type_id,$warehouse_location_id,$quantity,$delivery_preference);
                return $delivery_cost;
            }
          
        }
        
        
        /**
         * This is the function that determines if delivery city and store location city is the same
         */
        public function isDeliveryAndStoreLocationSameCity($delivery_city_id,$warehouse_location_id){
            if($delivery_city_id == $warehouse_location_id){
                return true;
            }
            return false;
        }
        
        
        
        /**
         * This is the function that determines if delivery city and store location city is in the same neighnbourhood
         */
        public function isDeliveryAndStoreLocationInSameNeighbourhood($delivery_city_id,$warehouse_location_id){
                $model = new NeighbourhoodCities;
                if($model->isThisCityAlreadyAssignedToANeighbourhood($delivery_city_id)){
                    $delivery_city_hood_id = $model->getTheNeighbourhoodIdOfThisCity($delivery_city_id);
                }else{
                    $delivery_city_hood_id = 0;
                }
                
                if($model->isThisCityAlreadyAssignedToANeighbourhood($warehouse_location_id)){
                    $store_city_hood_id = $model->getTheNeighbourhoodIdOfThisCity($warehouse_location_id);
                }else{
                    $store_city_hood_id = 0;
                }
                
                if($delivery_city_hood_id == 0){
                    return false;
                }else if($delivery_city_hood_id == $store_city_hood_id){
                    return true;
                }else{
                    return false;
                }
          
        }
        
        
        /**
         * Thsi is the function that determines if delivery city and the store city are in the same cluster
         */
        public function isDeliveryAndStoreLocationInSameCluster($delivery_city_id,$warehouse_location_id){
            $model = new ClusterNeighbourhoods;
            
            if($model->isThisCityNeighbourhoodAlreadyAssignedToACluster($delivery_city_id)){
                    $delivery_city_cluster_id = $model->getTheClusterIdOfThisCityNeighbourhood($delivery_city_id);
                }else{
                    $delivery_city_cluster_id = 0;
                }
                
                if($model->isThisCityNeighbourhoodAlreadyAssignedToACluster($warehouse_location_id)){
                    $store_city_cluster_id = $model->getTheClusterIdOfThisCityNeighbourhood($warehouse_location_id);
                }else{
                    $store_city_cluster_id = 0;
                }
                
                if($delivery_city_cluster_id == 0){
                    return false;
                }else if($delivery_city_cluster_id == $store_city_cluster_id){
                    return true;
                }else{
                    return false;
                }
            
            
            
        }
        
        
        /**
         * This is the function that determines if delivery cities and store location neighbourhoods are in separate clusters
         */
        public function isDeliveryAndStoreLocationOnSeparateCluster($delivery_city_id,$warehouse_location_id){
            $model = new ClusterNeighbourhoods;
            
            if($model->isThisCityNeighbourhoodAlreadyAssignedToACluster($delivery_city_id)){
                    $delivery_city_cluster_id = $model->getTheClusterIdOfThisCityNeighbourhood($delivery_city_id);
                }else{
                    $delivery_city_cluster_id = 0;
                }
                
                if($model->isThisCityNeighbourhoodAlreadyAssignedToACluster($warehouse_location_id)){
                    $store_city_cluster_id = $model->getTheClusterIdOfThisCityNeighbourhood($warehouse_location_id);
                }else{
                    $store_city_cluster_id = 0;
                }
                
                if($delivery_city_cluster_id == 0){
                    return false;
                }else if($store_city_cluster_id == 0){
                    return false;
                }else if($delivery_city_cluster_id == $store_city_cluster_id){
                    return false;
                }else{
                    return true;
                }
            
        }
        
        
        /**
         * This is the function that gets the weight equivalance of a measureent type
         */
        public function getTheWeightEquivalenaceInKgOfThisMeasurementType($measurement_type_id){
            $model = new MeasurementType;
            return $model->getTheWeightEquivalenaceInKgOfThisMeasurementType($measurement_type_id);
        }
        
        
        
        /**
         * This is the function that gets the intra city delivery cost of a city
         */
        public function getTheIntraCityDeliveryCostOfThisOrder($delivery_city_id,$measurement_type_id,$warehouse_location_id,$quantity,$delivery_preference){
            $model = new City;
            $weight_equivelance = $this->getTheWeightEquivalenaceInKgOfThisMeasurementType($measurement_type_id);
             $total_weight_for_delivery = (double)$weight_equivelance * (int)$quantity;
           if($delivery_preference == "standard"){
                $intra_city_rate = $model->getTheStandardIntraCityRateOfThisCity($delivery_city_id,$total_weight_for_delivery);
                $delivery_cost =(double)$intra_city_rate;
                return $delivery_cost;
           
         }else if($delivery_preference == "priority"){
                $intra_city_rate = $model->getThePriorityIntraCityRateOfThisCity($delivery_city_id,$total_weight_for_delivery);
                $delivery_cost =(double)$intra_city_rate;
                return $delivery_cost;
                
            }else if($delivery_preference == "sameday"){
                $intra_city_rate = $model->getTheSamedayIntraCityRateOfThisCity($delivery_city_id,$total_weight_for_delivery);
                $delivery_cost = (double)$intra_city_rate;
                return $delivery_cost;
            }
         
        }
        
        
        /**
         * This is the function that gets the intra neighbourhood deiverty cost
         */
        public function getTheIntraNeighbourhoodDeliveryCostOfThisOrder($delivery_city_id,$measurement_type_id,$warehouse_location_id,$quantity,$delivery_preference){
            $model = new Neighbourhood;
            $weight_equivelance = $this->getTheWeightEquivalenaceInKgOfThisMeasurementType($measurement_type_id);
             $total_weight_for_delivery = (double)$weight_equivelance * (int)$quantity;
          if($delivery_preference == "standard"){
                $intra_hood_rate = $model->getTheStandardIntraNeighbourhoodRateOfThisCity($delivery_city_id,$total_weight_for_delivery);
                $delivery_cost = (double)$intra_hood_rate;
               return $delivery_cost;
           
         }else if($delivery_preference == "priority"){
                $intra_hood_rate = $model->getThePriorityIntraNeighbourhoodRateOfThisCity($delivery_city_id,$total_weight_for_delivery);
                $delivery_cost = (double)$intra_hood_rate;
                return $delivery_cost;
                
            }else if($delivery_preference == "sameday"){
                $intra_hood_rate = $model->getTheSamedayIntraNeighbourhoodRateOfThisCity($delivery_city_id,$total_weight_for_delivery);
                $delivery_cost = (double)$intra_hood_rate;
                return $delivery_cost;
            }
         
            
        }
       
        
        /**
         * This is the function that gets the intra cluster delivery rate of a city's cluster
         */
        public function getTheIntraClusterDeliveryCostOfThisOrder($delivery_city_id,$measurement_type_id,$warehouse_location_id,$quantity,$delivery_preference){
            
            $model = new Cluster;
            $weight_equivelance = $this->getTheWeightEquivalenaceInKgOfThisMeasurementType($measurement_type_id);
             $total_weight_for_delivery = (double)$weight_equivelance * (int)$quantity;
            if($delivery_preference == "standard"){
                $intra_cluster_rate = $model->getTheStandardIntraClusterRateOfThisCity($delivery_city_id,$total_weight_for_delivery);
                $delivery_cost = (double)$intra_cluster_rate;
                return $delivery_cost;
                
                
            }else if($delivery_preference == "priority"){
                $intra_cluster_rate = $model->getThePriorityIntraClusterRateOfThisCity($delivery_city_id,$total_weight_for_delivery);
                $delivery_cost = (double)$intra_cluster_rate;
                return $delivery_cost;
                
            }else if($delivery_preference == "sameday"){
                $intra_cluster_rate = $model->getTheSamedayIntraClusterRateOfThisCity($delivery_city_id,$total_weight_for_delivery);
                $delivery_cost = (double)$intra_cluster_rate;
                return $delivery_cost;
            }
            
        }
        
        /**
         * This is the function that retrieves the inter cluster rate between two locations
         */
        public function getTheInterClusterDeliveryCostOfThisOrder($delivery_city_id,$measurement_type_id,$warehouse_location_id,$quantity,$delivery_preference){
            
            $model = new InterClusterRate;
            $weight_equivelance = $this->getTheWeightEquivalenaceInKgOfThisMeasurementType($measurement_type_id);
             $total_weight_for_delivery = (double)$weight_equivelance * (int)$quantity;
            if($delivery_preference == "standard"){
                $inter_cluster_rate = $model->getTheInterClusterRateOfTheseCities($delivery_city_id,$warehouse_location_id,$total_weight_for_delivery,$delivery_preference);
                $delivery_cost = (double)$intra_cluster_rate;
                return $delivery_cost;
                
                
            }else if($delivery_preference == "priority"){
                $intra_cluster_rate = $model->getTheInterClusterRateOfTheseCities($delivery_city_id,$warehouse_location_id,$total_weight_for_delivery,$delivery_preference);
                $delivery_cost = (double)$intra_cluster_rate;
                return $delivery_cost;
                
            }else if($delivery_preference == "sameday"){
                $intra_cluster_rate = $model->getTheInterClusterRateOfTheseCities($delivery_city_id,$warehouse_location_id,$total_weight_for_delivery,$delivery_preference);
                $delivery_cost = (double)$intra_cluster_rate;
                return $delivery_cost;
            }
            
        }
       
        
        /**
         * This is the function that retrieves the orphan location rate in the marketplace 
         */
        public function getTheOrphanLocationDeliveryCostOfThisOrder($delivery_city_id,$measurement_type_id,$warehouse_location_id,$quantity,$delivery_preference){
            $model = new GeneralPolicyAndSettings;
            
             $weight_equivelance = $this->getTheWeightEquivalenaceInKgOfThisMeasurementType($measurement_type_id);
             $total_weight_for_delivery = (double)$weight_equivelance * (int)$quantity;
             
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            //$criteria->condition='id=:id';
            //$criteria->params = array(':id'=>$hood_id);
            $policy = GeneralPolicyAndSettings::model()->find($criteria); 
            
             if($policy['default_orphan_maximum_base_weight']>=$total_weight_for_delivery){
                $orphan_rate = $policy['default_orphan_base_rate'];
            }else{
                $weight_diff = (double)$total_weight_for_delivery - (double)$policy['default_orphan_maximum_base_weight'];
                $orphan_rate = $policy['default_orphan_base_rate'] + ($weight_diff * (double)$policy['orphan_rate_per_additional_kg']);
             }
            
            $delivery_cost = (double)$orphan_rate;
            return $delivery_cost;
            
        }
        
        
        /**
         * This is the function that calculates the delivery cost of items in a cart
         */
        public function getTheDeliveryCostOfTheItemsInTheCart($cart_id,$delivery_city_id,$delivery_preference){
            $model = new CartItem;
            $total_cost_of_delivery = 0;
            
            //get all the items in this cart
            $items = $model->getAllTheItemsInThisCart($cart_id);
            foreach($items as $item){
                $measurement_type_id = $model->getTheMeasurementTypeOfThisCartItem($item);
                $warehouse_location_id = $model->getTheWarehouseLocationOfThisCartItem($item);
                $quantity = $model->getTheQuantityOfThisCartItem($item);
                $total_cost_of_delivery = $total_cost_of_delivery + $this->getTheDeliveryCostOfThisOrder($delivery_city_id,$measurement_type_id,$warehouse_location_id,$quantity,$delivery_preference);
            }
            
            return $total_cost_of_delivery;
            
        }
}
