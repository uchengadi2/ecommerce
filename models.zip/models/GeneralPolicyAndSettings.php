<?php

/**
 * This is the model class for table "general_policy_and_settings".
 *
 * The followings are the available columns in table 'general_policy_and_settings':
 * @property string $id
 * @property string $order_request
 * @property string $delivery_request
 * @property string $payment_on_delivery_request
 * @property string $deposit_payment_request
 * @property double $general_base_rate
 * @property string $base_rate_condition
 * @property double $at_one_delivery_threadshold
 * @property double $payment_on_delivery_threshold
 * @property double $minimum_total_order_value
 * @property double $minimum_initial_deposit_in_percentages
 * @property string $create_time
 * @property integer $create_user_id
 */
class GeneralPolicyAndSettings extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'general_policy_and_settings';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('create_user_id', 'numerical', 'integerOnly'=>true),
			array('general_base_rate, at_one_delivery_threadshold, payment_on_delivery_threshold, minimum_total_order_value, minimum_initial_deposit_in_percentages', 'numerical'),
			array('order_request', 'length', 'max'=>39),
			array('delivery_request', 'length', 'max'=>72),
			array('payment_on_delivery_request', 'length', 'max'=>53),
			array('deposit_payment_request', 'length', 'max'=>51),
			array('base_rate_condition', 'length', 'max'=>59),
			array('create_time', 'safe'),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('id, order_request, delivery_request, payment_on_delivery_request, deposit_payment_request, general_base_rate, base_rate_condition, at_one_delivery_threadshold, payment_on_delivery_threshold, minimum_total_order_value, minimum_initial_deposit_in_percentages, create_time, create_user_id', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'order_request' => 'Order Request',
			'delivery_request' => 'Delivery Request',
			'payment_on_delivery_request' => 'Payment On Delivery Request',
			'deposit_payment_request' => 'Deposit Payment Request',
			'general_base_rate' => 'General Base Rate',
			'base_rate_condition' => 'Base Rate Condition',
			'at_one_delivery_threadshold' => 'At One Delivery Threadshold',
			'payment_on_delivery_threshold' => 'Payment On Delivery Threshold',
			'minimum_total_order_value' => 'Minimum Total Order Value',
			'minimum_initial_deposit_in_percentages' => 'Minimum Initial Deposit In Percentages',
			'create_time' => 'Create Time',
			'create_user_id' => 'Create User',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('id',$this->id,true);
		$criteria->compare('order_request',$this->order_request,true);
		$criteria->compare('delivery_request',$this->delivery_request,true);
		$criteria->compare('payment_on_delivery_request',$this->payment_on_delivery_request,true);
		$criteria->compare('deposit_payment_request',$this->deposit_payment_request,true);
		$criteria->compare('general_base_rate',$this->general_base_rate);
		$criteria->compare('base_rate_condition',$this->base_rate_condition,true);
		$criteria->compare('at_one_delivery_threadshold',$this->at_one_delivery_threadshold);
		$criteria->compare('payment_on_delivery_threshold',$this->payment_on_delivery_threshold);
		$criteria->compare('minimum_total_order_value',$this->minimum_total_order_value);
		$criteria->compare('minimum_initial_deposit_in_percentages',$this->minimum_initial_deposit_in_percentages);
		$criteria->compare('create_time',$this->create_time,true);
		$criteria->compare('create_user_id',$this->create_user_id);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return GeneralPolicyAndSettings the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
        
        
        /**
         * This is the function that gets the preferred measurement type in the market place for customer orders
         */
        public function getThePreferredMeasurementType(){
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $policy = GeneralPolicyAndSettings::model()->find($criteria); 
            
            if($policy['measurement_type_preference'] == NULL){
                return 'product_classification';
            }            
            return $policy['measurement_type_preference'];
        }
}
