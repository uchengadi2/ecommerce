<?php

/**
 * This is the model class for table "membership".
 *
 * The followings are the available columns in table 'membership':
 * @property string $id
 * @property string $member_id
 * @property double $monthly_membership_fee
 * @property string $membership_type
 * @property string $status
 * @property string $membership_number
 * @property string $subscription_start_date
 * @property string $subscription_end_date
 * @property string $membership_start_date
 */
class Membership extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'membership';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('member_id, membership_type, membership_number', 'required'),
			array('monthly_membership_fee', 'numerical'),
			array('member_id', 'length', 'max'=>10),
			array('membership_type', 'length', 'max'=>6),
			array('status', 'length', 'max'=>20),
			array('membership_number', 'length', 'max'=>250),
			array('subscription_start_date, subscription_end_date, membership_start_date', 'safe'),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('id, member_id, monthly_membership_fee, membership_type, status, membership_number, subscription_start_date, subscription_end_date, membership_start_date', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'member_id' => 'Member',
			'monthly_membership_fee' => 'Monthly Membership Fee',
			'membership_type' => 'Membership Type',
			'status' => 'Status',
			'membership_number' => 'Membership Number',
			'subscription_start_date' => 'Subscription Start Date',
			'subscription_end_date' => 'Subscription End Date',
			'membership_start_date' => 'Membership Start Date',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('id',$this->id,true);
		$criteria->compare('member_id',$this->member_id,true);
		$criteria->compare('monthly_membership_fee',$this->monthly_membership_fee);
		$criteria->compare('membership_type',$this->membership_type,true);
		$criteria->compare('status',$this->status,true);
		$criteria->compare('membership_number',$this->membership_number,true);
		$criteria->compare('subscription_start_date',$this->subscription_start_date,true);
		$criteria->compare('subscription_end_date',$this->subscription_end_date,true);
		$criteria->compare('membership_start_date',$this->membership_start_date,true);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return Membership the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
        
        
         /**
         * This is the function that determines if a user is a ptime meber
         */
        public function isThisUserAPrimeMember($prime_member_number){
            $model = new Membership;
           
            $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('membership')
                    ->where("membership_number = '$prime_member_number' and membership_type='prime'");
                $result = $cmd->queryScalar();
                
                if($result>0){
                    return true;
                }else{
                    return false;
                }
        }
        
        
        /**
         * This is the function that confirms if a logged in user is a prime user
         */
        public function isThisUserIdAPrimeMember($user_id){
             $model = new Membership;
           
            $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('membership')
                    ->where("member_id = $user_id and membership_type='prime'");
                $result = $cmd->queryScalar();
                
                if($result>0){
                    return true;
                }else{
                    return false;
                }
        }
        
        
         /**
         * This is the function that retrieves the membership number of this prime user
         */
        public function getTheMembershipNumberOfThisUser($user_id){
            $model = new Membership;
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='member_id=:memberid';
            $criteria->params = array(':memberid'=>$user_id);
            $membership= Membership::model()->find($criteria);
            
            return $membership['membership_number'];
        }
        
        
        /**
         * This is the function that set the end of a  subscription date
         */
        public function getSubscriptionEndDate($duration,$period){
            
            $today = date("Y-m-d",mktime(0, 0, 0, date("m")  , date("d"), date("Y")));
            if($period == "monthly"){
                $end_date = date("Y-m-d",mktime(0, 0, 0, date("m")+$duration  , date("d")-1, date("Y")));
            }else if($period == "yearly"){
                $monthly = $duration * 12;
                $end_date = date("Y-m-d",mktime(0, 0, 0, date("m")+$monthly  , date("d")-1, date("Y")));
            }
            return $end_date;
        }
        
        
        /**
         * This is the function that generates the membership number of a new member
         */
        public function generateMembershipNumber(){
             //get the date of an order
                //$membership_start_date = date("dmY",$this->getTheStartDateOfThisMember());
                $membership_start_date = date("m",$this->getTheStartDateOfThisMember());
                
                  //generate a random number
                    $random_number = $this->generateTheRandomNumber();
                if($this->isThisMonthAnOddNumber($membership_start_date)){
                     //get the membership number
                    $membership_number = "$random_number$membership_start_date";
                    
                }else{
                     //get the membership number
                    $membership_number = "$membership_start_date$random_number";
                }
               
                
                
                
                return $membership_number;
            
        }
        
        
        
        /**
         * This is function that determines if a month is divisible by 2
         */
        public function isThisMonthAnOddNumber($membership_start_date){
            if((double)$membership_start_date%2>0){
                return true;
            }else{
                return false;
            }
        }
      
        
        
          /**
            * This is the function that fetches the start  date of a member
            */
            public function getTheStartDateOfThisMember(){
                //get todays date
                $today = mktime(0, 0, 0, date("m")  , date("d"), date("Y"));
                
               return $today;
            }
            
            
             /**
             * This is the function that generates a random number
             */
            public function generateTheRandomNumber(){
                
                //get todays date
                $today = mktime(0, 0, 0, date("m")  , date("d"), date("Y"));
                //generate random numbe from 0 to $today
                $random_number = mt_rand(0,$today);
               return $random_number;
            }
            
            
             /**
             * This is the function that gets the order number first four letters
             */
            public function getTheFirstFourLettersOfTheOrderNumber($order_number){
                
                return substr($order_number,0,4);
            }
            
            
             /**
         * This is the function that confirms if a logged in user is already a member
         */
        public function isThisUserAlreadyMember($user_id){
             $model = new Membership;
           
            $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('membership')
                    ->where("member_id = $user_id");
                $result = $cmd->queryScalar();
                
                if($result>0){
                    return true;
                }else{
                    return false;
                }
        }
        
            
           
}
