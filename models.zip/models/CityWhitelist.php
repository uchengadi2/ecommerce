<?php

/**
 * This is the model class for table "city_whitelist".
 *
 * The followings are the available columns in table 'city_whitelist':
 * @property string $id
 * @property string $city_id
 * @property string $create_time
 * @property integer $create_user_id
 */
class CityWhitelist extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'city_whitelist';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('city_id', 'required'),
			array('create_user_id', 'numerical', 'integerOnly'=>true),
			array('city_id', 'length', 'max'=>10),
			array('create_time', 'safe'),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('id, city_id, create_time, create_user_id', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'city_id' => 'City',
			'create_time' => 'Create Time',
			'create_user_id' => 'Create User',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('id',$this->id,true);
		$criteria->compare('city_id',$this->city_id,true);
		$criteria->compare('create_time',$this->create_time,true);
		$criteria->compare('create_user_id',$this->create_user_id);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return CityWhitelist the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
        
        
        /**
         * This is the function that list all cities on a whitelist
         */
        public function retrieveAllCitiesOnTheWhiteList(){
            $target = [];
            $whitelist = CityWhitelist::model()->findAll();
            foreach($whitelist as $list){
                $target[] = $list['city_id'];
            }
            return $target;
        }
        
        
               
        /**
         * This is the function that confirms if a city is in the whitelist
         */
        public function isThisCityInTheWhitelist($city_id){
            $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('city_whitelist')
                    ->where("city_id = $city_id");
                $result = $cmd->queryScalar();
                
                if($result>0){
                    return true;
                }else{
                    return false;
                }
        }
        
        
        /**
         * This is the function that confirms the deletion of a city from a whitelist
         */
        public function isTheRemovalOfThisCityFromTheWhitelistASuccess($city_id){
             $cmd =Yii::app()->db->createCommand();  
                $result = $cmd->delete('city_whitelist', 'city_id=:cityid', array(':cityid'=>$city_id));
            
                if($result>0){
                    return true;
                    
                }else{
                    return false;
                }
        }
        
}
