<?php

/**
 * This is the model class for table "classification_measurement_type".
 *
 * The followings are the available columns in table 'classification_measurement_type':
 * @property string $id
 * @property string $measurement_type_id
 * @property string $classification
 * @property string $create_time
 * @property integer $create_user_id
 */
class ClassificationMeasurementType extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'classification_measurement_type';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('measurement_type_id, classification', 'required'),
			array('create_user_id', 'numerical', 'integerOnly'=>true),
			array('measurement_type_id', 'length', 'max'=>10),
			array('classification', 'length', 'max'=>22),
			array('create_time', 'safe'),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('id, measurement_type_id, classification, create_time, create_user_id', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'measurement_type_id' => 'Measurement Type',
			'classification' => 'Classification',
			'create_time' => 'Create Time',
			'create_user_id' => 'Create User',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('id',$this->id,true);
		$criteria->compare('measurement_type_id',$this->measurement_type_id,true);
		$criteria->compare('classification',$this->classification,true);
		$criteria->compare('create_time',$this->create_time,true);
		$criteria->compare('create_user_id',$this->create_user_id);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return ClassificationMeasurementType the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
        
        
        /**
         * This is the function that retrieves all measurement type for a classification
         */
        public function retrieveAllMeasurementTypesAlreadyAssignedToAClassification($classification){
            $target = [];
            
              $criteria = new CDbCriteria();
              $criteria->select = '*';
              $criteria->condition='classification=:classid';
              $criteria->params = array(':classid'=>"$classification");
              $types= ClassificationMeasurementType::model()->findall($criteria);
              
              
              if($types !=null){
                foreach($types as $type){
                  $target[] = $type['measurement_type_id'];
                    }
              
              return $target;
                  
              }else{
                  return null;
              }
             
        }
        
        
        
        /**
         * This is the function that confirms if a measurement type is already assigned to a classification
         */
        public function isThisMeasurementTypeAlreadyAssignedToThisClassification($classification,$measurement_type_id){
            
             $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('classification_measurement_type')
                    ->where("classification = '$classification' and measurement_type_id=$measurement_type_id");
                $result = $cmd->queryScalar();
                
                if($result>0){
                    return true;
                }else{
                    return false;
                }
            
        }
        
        
        /**
         * This is the function that confirms if a the removal of measurement type is a success
         */
        public function isTheRemovalOfThisMeasurementTypeFromClassificationASuccess($classification,$measurement_type_id){
             $cmd =Yii::app()->db->createCommand();  
                $result = $cmd->delete('classification_measurement_type', 'classification=:class and measurement_type_id=:type', array(':class'=>$classification,':type'=>$measurement_type_id));
            
                if($result>0){
                    return true;
                    
                }else{
                    return false;
                }
        }
}
