<?php

/**
 * This is the model class for table "order_item".
 *
 * The followings are the available columns in table 'order_item':
 * @property string $id
 * @property string $order_id
 * @property string $product_id
 * @property double $quantity
 * @property integer $is_item_delivery_splittable
 * @property string $date_ordered
 * @property integer $ordered_by
 * @property integer $quantity_measurement_type_id
 */
class OrderItem extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'order_item';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('order_id, product_id', 'required'),
			array('is_item_delivery_splittable, ordered_by, quantity_measurement_type_id', 'numerical', 'integerOnly'=>true),
			array('quantity', 'numerical'),
			array('order_id, product_id', 'length', 'max'=>10),
			array('date_ordered', 'safe'),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('id, order_id, product_id, quantity, is_item_delivery_splittable, date_ordered, ordered_by, quantity_measurement_type_id', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'order_id' => 'Order',
			'product_id' => 'Product',
			'quantity' => 'Quantity',
			'is_item_delivery_splittable' => 'Is Item Delivery Splittable',
			'date_ordered' => 'Date Ordered',
			'ordered_by' => 'Ordered By',
			'quantity_measurement_type_id' => 'Quantity Measurement Type',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('id',$this->id,true);
		$criteria->compare('order_id',$this->order_id,true);
		$criteria->compare('product_id',$this->product_id,true);
		$criteria->compare('quantity',$this->quantity);
		$criteria->compare('is_item_delivery_splittable',$this->is_item_delivery_splittable);
		$criteria->compare('date_ordered',$this->date_ordered,true);
		$criteria->compare('ordered_by',$this->ordered_by);
		$criteria->compare('quantity_measurement_type_id',$this->quantity_measurement_type_id);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return OrderItem the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
        
        
        /**
         * This is the function that retrieves an merchant items in an order
         */
        public function isThisOrderWithMerchantProduct($order_id,$merchant_id){
            
            $model  = new Product;
             //select all order items
            
            $criteria = new CDbCriteria();
            $criteria->select = '*';
            $criteria->condition='order_id=:orderid';
            $criteria->params = array(':orderid'=>$order_id);
            $items= OrderItem::model()->findAll($criteria);
            
            foreach($items as $item){
                if($model->isThisOrderItemForThisMerchant($item['product_id'],$merchant_id)){
                    return true;
                }
            }
            return false;
            
        }
        
        
        /**
         * this is the function that confirms if an order is assigned to a contractor
         */
        public function isThisOrderAssignedToThisCarrier($order_id,$contractor_id){
            $cmd =Yii::app()->db->createCommand();
                $cmd->select('COUNT(*)')
                    ->from('order_item')
                    ->where("order_id = $order_id and courier_id=$contractor_id");
                $result = $cmd->queryScalar();
                
                if($result>0){
                    return true;
                }else{
                    return false;
                }
        }
        
        
         /**
         * This is the function that adds an item to an order
         */
        public function isOrderItemDetailsCorrectlyCreated($order_id,$product_id,$quantity,$measurement_type_id,$promotion_id,$pricing_id,$ordered_by,$cost_per_unit,$unit,$prime_customer_discount_rate){
            $model = new OrderItem;
            
            $model->order_id = $order_id;
            $model->product_id =$product_id;
            $model->quantity = $quantity;
            $model->quantity_measurement_type_id = $measurement_type_id;
            $model->promotion_id = $promotion_id;
            $model->pricing_id =$pricing_id;
            $model->cost_per_unit = $cost_per_unit;
            $model->prime_customer_discount_rate= $prime_customer_discount_rate;
            $model->unit = $unit;       
            $model->ordered_by = $ordered_by;
            $model->date_ordered = new CDbExpression('NOW()');
            
            
            if($model->save()){
                return true;
            }else{
                return false;
            }
            
        }
}
