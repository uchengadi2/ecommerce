<?php

/**
 * This is the model class for table "payment".
 *
 * The followings are the available columns in table 'payment':
 * @property string $id
 * @property string $status
 * @property string $payment_mode
 * @property string $preference
 * @property string $invoice_number
 * @property string $order_id
 * @property double $amount_paid
 * @property double $order_total_amount
 * @property string $remark
 * @property string $payment_date
 * @property integer $paid_by
 * @property integer $payment_confirmed_by
 * @property string $date_of_confirmation
 */
class Payment extends CActiveRecord
{
	/**
	 * @return string the associated database table name
	 */
	public function tableName()
	{
		return 'payment';
	}

	/**
	 * @return array validation rules for model attributes.
	 */
	public function rules()
	{
		// NOTE: you should only define rules for those attributes that
		// will receive user inputs.
		return array(
			array('status, order_id, amount_paid, order_total_amount', 'required'),
			array('paid_by, payment_confirmed_by', 'numerical', 'integerOnly'=>true),
			array('amount_paid, order_total_amount', 'numerical'),
			array('status', 'length', 'max'=>11),
			array('payment_mode', 'length', 'max'=>50),
			array('preference', 'length', 'max'=>7),
			array('invoice_number', 'length', 'max'=>50),
			array('order_id', 'length', 'max'=>10),
			array('remark', 'length', 'max'=>200),
			array('payment_date, date_of_confirmation', 'safe'),
			// The following rule is used by search().
			// @todo Please remove those attributes that should not be searched.
			array('id, status, payment_mode, preference, invoice_number, order_id, amount_paid, order_total_amount, remark, payment_date, paid_by, payment_confirmed_by, date_of_confirmation', 'safe', 'on'=>'search'),
		);
	}

	/**
	 * @return array relational rules.
	 */
	public function relations()
	{
		// NOTE: you may need to adjust the relation name and the related
		// class name for the relations automatically generated below.
		return array(
		);
	}

	/**
	 * @return array customized attribute labels (name=>label)
	 */
	public function attributeLabels()
	{
		return array(
			'id' => 'ID',
			'status' => 'Status',
			'payment_mode' => 'Payment Mode',
			'preference' => 'Preference',
			'invoice_number' => 'Invoice Number',
			'order_id' => 'Order',
			'amount_paid' => 'Amount Paid',
			'order_total_amount' => 'Order Total Amount',
			'remark' => 'Remark',
			'payment_date' => 'Payment Date',
			'paid_by' => 'Paid By',
			'payment_confirmed_by' => 'Payment Confirmed By',
			'date_of_confirmation' => 'Date Of Confirmation',
		);
	}

	/**
	 * Retrieves a list of models based on the current search/filter conditions.
	 *
	 * Typical usecase:
	 * - Initialize the model fields with values from filter form.
	 * - Execute this method to get CActiveDataProvider instance which will filter
	 * models according to data in model fields.
	 * - Pass data provider to CGridView, CListView or any similar widget.
	 *
	 * @return CActiveDataProvider the data provider that can return the models
	 * based on the search/filter conditions.
	 */
	public function search()
	{
		// @todo Please modify the following code to remove attributes that should not be searched.

		$criteria=new CDbCriteria;

		$criteria->compare('id',$this->id,true);
		$criteria->compare('status',$this->status,true);
		$criteria->compare('payment_mode',$this->payment_mode,true);
		$criteria->compare('preference',$this->preference,true);
		$criteria->compare('invoice_number',$this->invoice_number,true);
		$criteria->compare('order_id',$this->order_id,true);
		$criteria->compare('amount_paid',$this->amount_paid);
		$criteria->compare('order_total_amount',$this->order_total_amount);
		$criteria->compare('remark',$this->remark,true);
		$criteria->compare('payment_date',$this->payment_date,true);
		$criteria->compare('paid_by',$this->paid_by);
		$criteria->compare('payment_confirmed_by',$this->payment_confirmed_by);
		$criteria->compare('date_of_confirmation',$this->date_of_confirmation,true);

		return new CActiveDataProvider($this, array(
			'criteria'=>$criteria,
		));
	}

	/**
	 * Returns the static model of the specified AR class.
	 * Please note that you should have this exact method in all your CActiveRecord descendants!
	 * @param string $className active record class name.
	 * @return Payment the static model class
	 */
	public static function model($className=__CLASS__)
	{
		return parent::model($className);
	}
        
        /**
         * This is the function that confirms if the payment of an order was confirmed
         */
        public function isThePaymentOfThisOrderConfirmed($order_id){
            $criteria = new CDbCriteria();
              $criteria->select = '*';
              $criteria->condition='order_id=:orderid';
              $criteria->params = array(':orderid'=>$order_id);
              $payment= Payment::model()->find($criteria);
              
              if($payment['status'] == "confirmed"){
                  return true;
              }
            return false;
        }
        
        
        
         /**
         * This is the function that effects an order payment
         */
        public function makePaymentAndGenerateTheInvoiceNumber($order_id,$order_number,$payment_mode,$delivery_cost,$total_cost_deposit,$total_price_of_items,$ordered_by,$cart_id,$warehouse_location_id,$delivery_city_id){
            $model = new Payment;
           
            $model->status = "pending";
            $model->payment_mode= "$payment_mode";
            $model->invoice_number =$this->generateInvoiceNumber($order_number,$cart_id,$warehouse_location_id,$delivery_city_id);
            $model->order_id =$order_id;
            $model->delivery_cost = $delivery_cost;
            $model->amount_paid= $total_cost_deposit;
            $model->order_total_amount = $total_price_of_items;
            $model->payment_date=new CDbExpression('NOW()');
            $model->paid_by = $ordered_by;
            
            if($model->save()){
                return $model->invoice_number;
            }else{
                return 0;
            }
            
        }
        
        
        /**
         * This is the function that generates a payment reciepts
         */
        public function generateInvoiceNumber($order_number,$cart_id,$warehouse_location_id,$delivery_city_id){
            $model = new Order;
            $random_number = $model->generateTheRandomNumber();
            //get the date of this order
             $order_date = $model->getTheDateOfThisOrder(); 
             //get the first four letters of the order number
             $order_number_first_four_letters = strtoupper($model->getTheFirstFourLettersOfTheOrderNumber($order_number));
             
             $invoice_number = "$random_number-$order_number_first_four_letters$cart_id$warehouse_location_id$delivery_city_id";
             return $invoice_number;
             
             
        }
        
        
}
