<?php

class CategoryController extends Controller
{
	/**
	 * @var string the default layout for the views. Defaults to '//layouts/column2', meaning
	 * using two-column layout. See 'protected/views/layouts/column2.php'.
	 */
	public $layout='//layouts/column2';

	/**
	 * @return array action filters
	 */
	public function filters()
	{
		return array(
			'accessControl', // perform access control for CRUD operations
			'postOnly + delete', // we only allow deletion via POST request
		);
	}

	/**
	 * Specifies the access control rules.
	 * This method is used by the 'accessControl' filter.
	 * @return array access control rules
	 */
	public function accessRules()
	{
		return array(
			array('allow',  // allow all users to perform 'index' and 'view' actions
				'actions'=>array('index','view'),
				'users'=>array('*'),
			),
			array('allow', // allow authenticated user to perform 'create' and 'update' actions
				'actions'=>array('create','update','listAllCategories','addnewcategory','updatecategory','deleteonecategory',
                                    'setthiscategorybaserate','zerorisethiscategorybaserate'),
				'users'=>array('@'),
			),
			array('allow', // allow admin user to perform 'admin' and 'delete' actions
				'actions'=>array('admin','delete'),
				'users'=>array('admin'),
			),
			array('deny',  // deny all users
				'users'=>array('*'),
			),
		);
	}

	/**
         * This is the function that list all categorues
         */
        public function actionlistAllCategories(){
            
            $model = new Category;
            
             $category = Category::model()->findAll();
                if($category===null) {
                    http_response_code(404);
                    $data['error'] ='No record found';
                    echo CJSON::encode($data);
                } else {
                        header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() == 0,
                                    "category" => $category,
                                   
                    
                            ));
                       
                }
            
        }
        
        
        /**
         * This is the function that adds new category
         */
        public function actionaddnewcategory(){
            
            $model=new Category;

		// Uncomment the following line if AJAX validation is needed
		// $this->performAjaxValidation($model);

                $model->name = $_POST['name'];
                if(isset($_POST['description'])){
                   $model->description = $_POST['description']; 
                }
                                 
                $model->create_time = new CDbExpression('NOW()');
                $model->create_user_id = Yii::app()->user->id;
                
                $icon_error_counter = 0;
                
                 if($_FILES['icon']['name'] != ""){
                    if($model->isIconTypeAndSizeLegal()){
                        
                       $icon_filename = $_FILES['icon']['name'];
                     
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $icon_filename = NULL;   
                   //$icon_size = 0;
             
                }//end of the if icon is empty statement
                if($icon_error_counter ==0){
                   if($model->validate()){
                           $model->icon = $model->moveTheIconToItsPathAndReturnTheIconName($model,$icon_filename);
                         
                           
                       if($model->save()) {
                        
                                $msg = "'$model->name' category was added successful";
                                 header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                 "success" => mysqli_connect_errno() == 0,
                                  "msg" => $msg)
                            );
                         
                        }else{
                            //delete all the moved files in the directory when validation error is encountered
                            $msg = 'Validaion Error: Check your file fields for correctness';
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                               );
                          }
                            }else{
                                
                                //delete all the moved files in the directory when validation error is encountered
                            $msg = "Validation Error: '$model->name'  category was not added";
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                            );
                          }
                   }elseif($icon_error_counter > 0){
                        $msg = "Please check the image you uploaded and ensure that they meet the requirements. Note that the images must have a minimum size of 1000px by 1000px and they must either be in  .png or .jpg file format";
                            header('Content-Type: application/json');
                                    echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                    "msg" => $msg)
                            );
                         
                        } 
        }
        
        
        
        /**
         * This is the function that updates the category information
         */
        public function actionupdatecategory(){
            
             $_id = $_POST['id'];
             $model=Category::model()->findByPk($_id);
             
             $model->name = $_POST['name'];
                if(isset($_POST['description'])){
                   $model->description = $_POST['description']; 
                }
                                 
                $model->update_time = new CDbExpression('NOW()');
                $model->update_user_id = Yii::app()->user->id;
                
                $icon_error_counter = 0;
                
                 if($_FILES['icon']['name'] != ""){
                    if($model->isIconTypeAndSizeLegal()){
                        
                       $icon_filename = $_FILES['icon']['name'];
                      //$icon_size = $_FILES['flag']['size'];
                        
                    }else{
                       
                        $icon_error_counter = $icon_error_counter + 1;
                         
                    }//end of the determine size and type statement
                }else{
                    $icon_filename = $model->retrieveThePreviousIconName($_id);
                   //$icon_size = 0;
             
                }//end of the if icon is empty statement
                if($icon_error_counter ==0){
                   if($model->validate()){
                           $model->icon = $model->moveTheIconToItsPathAndReturnTheIconName($model,$icon_filename);
                           
                           
                       if($model->save()) {
                        
                                $msg = "'$model->name' category was updated successful";
                                 header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                 "success" => mysqli_connect_errno() == 0,
                                  "msg" => $msg)
                            );
                         
                        }else{
                            //delete all the moved files in the directory when validation error is encountered
                            $msg = 'Validaion Error: Check your file fields for correctness';
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                               );
                          }
                            }else{
                                
                                //delete all the moved files in the directory when validation error is encountered
                            $msg = "Validation Error: '$model->name' category  was not updated";
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                            );
                          }
                   }elseif($icon_error_counter > 0){
                        $msg = "Please check the image you uploaded and ensure that they meet the requirements. Note that the images must have a minimum size of 1000px by 1000px and they must either be in  .png or .jpg file format";
                            header('Content-Type: application/json');
                                    echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                    "msg" => $msg)
                            );
                         
                        } 
         
        }
        
        
        
        /**
         * This is the function that deletes a category from the database
         */
        public function actiondeleteonecategory(){
            
            $_id = $_POST['id'];
            $model=Category::model()->findByPk($_id);
            
            
            if($model->isTheRemovalOfCategoryImageASuccess($_id)){
                //get the category name
            $category_name = $model->getThisCategoryName($_id);
            if($model === null){
                $data['success'] = 'undefined';
                $data['msg'] = 'No such record exist';
                header('Content-Type: application/json');
                echo CJSON::encode($data);
                                      
            }else if($model->delete()){
                    $data['success'] = 'true';
                    $data['msg'] = "'$category_name' category was successfully deleted";
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
            } else {
                    $data['success'] = 'false';
                    $data['msg'] = 'deletion was unsuccessful';
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
                            
                }
                
            }else{
                $data['success'] = 'false';
                    $data['msg'] = 'deletion was unsuccessful';
                     header('Content-Type: application/json');
                    echo CJSON::encode($data);
            }
            
            
            
        }
        
        
        /**
         * This is the function that sets a new base rate for a category
         */
        public function actionsetthiscategorybaserate(){
            
            $_id = $_POST['category_id'];
             $model=Category::model()->findByPk($_id);
             
             $model->category_base_rate = $_REQUEST['base_rate'];
             $model->name = $_REQUEST['category_name'];
             
             if($model->save()){
                $msg = "'$model->name' category base rate was successful set";
                                 header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                 "success" => mysqli_connect_errno() == 0,
                                  "msg" => $msg)
                            );
             }else{
                 $msg = "'$modei->name' category base rate could not be set. Please try again or contact support service";
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                               );
             }
        }
        
        
        /**
         * This is the function that zerorises a category base rate
         */
        public function actionzerorisethiscategorybaserate(){
            
            $_id = $_POST['category_id'];
             $model=Category::model()->findByPk($_id);
             
             $model->category_base_rate = 0.00;
             $model->name = $_REQUEST['category_name'];
                          
             if($model->save()){
                $msg = "'$model->name' category base rate had been zerorised";
                                 header('Content-Type: application/json');
                                echo CJSON::encode(array(
                                 "success" => mysqli_connect_errno() == 0,
                                  "msg" => $msg)
                            );
             }else{
                 $msg = "'$modei->name' category base rate could not be zerorised. Please try again or contact support service for assistance";
                            header('Content-Type: application/json');
                            echo CJSON::encode(array(
                                    "success" => mysqli_connect_errno() != 0,
                                        "msg" => $msg)
                               );
             }
        }
}
