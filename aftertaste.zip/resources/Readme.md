# ext-theme-neptune-04437ba8-4afc-44a9-a125-93e53265ed46/resources

This folder contains static resources (typically an `"images"` folder as well).
