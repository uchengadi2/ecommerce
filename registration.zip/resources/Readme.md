# ext-theme-neptune-57dffcc7-0aeb-4095-8549-d30b9d99de2d/resources

This folder contains static resources (typically an `"images"` folder as well).
