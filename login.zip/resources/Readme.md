# ext-theme-neptune-ed7987bf-6d2d-4324-bcb4-418b1aad5986/resources

This folder contains static resources (typically an `"images"` folder as well).
